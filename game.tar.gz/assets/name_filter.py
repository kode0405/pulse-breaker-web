"""Offline, conservative nickname checks. No network calls or raw-name logging."""
import re
import unicodedata as ud

# Longer expressions are intentional: neutral identity words and common names are allowed.
KOREAN = (
    '씨발', '시발', '씨팔', '시팔', '씨바', '씹새', '씹년', '씹놈', '씹창',
    '개새끼', '개세끼', '개색기', '개새기', '개쌔끼', '개년', '개놈', '개같은',
    '병신', '븅신', '빙신', '지랄', '좆', '좃', '존나', '졸라', '보지', '자지',
    '느금', '느개비', '느그엄마', '느그애미', '느그애비', '니애미', '니애비',
    '니에미', '니엄마', '너네엄마', '니아빠', '애미뒤', '애비뒤', '엄마뒤',
    '니기미', '느검마', '엄창', '홍어새끼', '전라디언', '페미충', '개독', '돼지새끼',
    '창녀', '창놈', '걸레년', '걸레같', '따먹', '강간', '성노예',
    '한남충', '한녀충', '김치녀', '된장녀', '맘충', '급식충', '틀딱',
    '쪽바리', '짱깨', '짱개', '장애충', '장애새끼', '정신병자', '흑형충',
)
ENGLISH_LONG = ('fuck', 'bitch', 'asshole', 'nigger', 'nigga', 'retard', 'motherf',
                'tlqkf', 'qudtls', 'wlfkf', 'rotorl', 'ssibal')
ENGLISH_EXACT = {'shit', 'cunt', 'fag', 'pussy', 'whore', 'sibal', 'sipal', 'stfu', 'wtf', 'fck', 'fcuk', 'fuk'}
ABBREVIATIONS = {'ㅅㅂ', 'ㅆㅂ', 'ㅂㅅ', 'ㅄ', 'ㅈㄹ', 'ㅆㅃ', 'ㄴㄱㅁ'}
INITIALS = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ'
VOWELS = 'ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ'
FINALS = ('ㄱ','ㄲ','ㄱㅅ','ㄴ','ㄴㅈ','ㄴㅎ','ㄷ','ㄹ','ㄹㄱ','ㄹㅁ','ㄹㅂ','ㄹㅅ',
          'ㄹㅌ','ㄹㅍ','ㄹㅎ','ㅁ','ㅂ','ㅂㅅ','ㅅ','ㅆ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ')


def _normalize(text):
    return ud.normalize('NFKC', text).casefold()


def _phonetic(text):
    pieces = []
    for char in ud.normalize('NFKD', text):
        code = ord(char)
        if 0x1100 <= code <= 0x1112:
            pieces.append(INITIALS[code - 0x1100])
        elif 0x1161 <= code <= 0x1175:
            pieces.append(VOWELS[code - 0x1161])
        elif 0x11A8 <= code <= 0x11C2:
            pieces.append(FINALS[code - 0x11A8])
    value = ''.join(pieces).translate(str.maketrans('ㄲㄸㅃㅆㅉ', 'ㄱㄷㅂㅅㅈ'))
    return re.sub(r'(.)\1+', r'\1', value)


PATTERNS = tuple(_phonetic(word) for word in KOREAN)


def name_problem(text):
    """Return a user-facing reason, or None. Blank names are permitted (auto alias)."""
    if not isinstance(text, str):
        return '다른 별명이나 참가 번호를 입력해 주세요.'
    normal = _normalize(text)
    if not normal.strip():
        return None
    hangul = _phonetic(normal)
    if any(word in hangul for word in PATTERNS):
        return '사용할 수 없는 표현입니다. 다른 별명이나 참가 번호를 써 주세요.'
    explicit_jamo = ''.join(c for c in text if 0x3131 <= ord(c) <= 0x318E or 0x1100 <= ord(c) <= 0x11FF)
    if explicit_jamo and _phonetic(explicit_jamo) in {_phonetic(a) for a in ABBREVIATIONS}:
        return '사용할 수 없는 표현입니다. 다른 별명이나 참가 번호를 써 주세요.'
    ascii_text = normal.translate(str.maketrans({'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s'}))
    compact = ''.join(c for c in ascii_text if 'a' <= c <= 'z')
    words = re.findall(r'[a-z]+', ascii_text)
    if any(word in compact for word in ENGLISH_LONG) or compact in ENGLISH_EXACT or any(w in ENGLISH_EXACT for w in words):
        return '사용할 수 없는 표현입니다. 다른 별명이나 참가 번호를 써 주세요.'
    if any(ud.category(c).startswith('C') for c in text):
        return '보이지 않는 문자나 제어 문자는 사용할 수 없어요.'
    if not any(c.isalnum() for c in normal):
        return '글자나 숫자가 포함된 별명을 써 주세요.'
    return None


def safe_name(text):
    """Sanitize legacy or externally edited records without deleting their scores."""
    if name_problem(text):
        return '플레이어'
    return ud.normalize('NFKC', text).strip()[:12] or '플레이어'
