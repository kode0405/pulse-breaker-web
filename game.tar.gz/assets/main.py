import asyncio
import json
import sys
import pygame
from pulse_breaker import App, World, safe_name

IS_WEB = sys.platform == 'emscripten'
if IS_WEB:
    import platform


class BrowserApp(App):
    def load(self):
        if not IS_WEB:
            return super().load()
        try:
            raw=json.loads(str(platform.window.localStorage.getItem('pulse-breaker:'+self.save_file) or '{}'))
            if not isinstance(raw,dict):raise ValueError('invalid preferences')
            rows=raw.get('records',[])
            if not isinstance(rows,list):rows=[]
            self.records=[dict(r,name=safe_name(r['name'])) for r in rows
                          if isinstance(r,dict) and isinstance(r.get('name'),str)
                          and type(r.get('score')) is int and 0<=r['score']<10**15][:100]
            self.audio.enabled=bool(raw.get('sound',True));self.reduced=bool(raw.get('reduced',False))
            value=raw.get('character',0)
            self.character=value if type(value) is int and 0<=value<4 else 0
        except Exception:
            self.storage_ok=False

    def persist(self):
        if not IS_WEB:
            return super().persist()
        try:
            raw=dict(records=self.records,sound=self.audio.enabled,reduced=self.reduced,character=self.character)
            platform.window.localStorage.setItem('pulse-breaker:'+self.save_file,json.dumps(raw,ensure_ascii=False))
            self.storage_ok=True
        except Exception:
            self.storage_ok=False

    def activate(self,key):
        if IS_WEB and key=='exit':
            self.state='menu';self.clear_input();self.audio.stop()
            platform.window.parent.postMessage('pulse-breaker:exit','*')
            return
        return super().activate(key)


async def main():
    festival=IS_WEB and 'mode=festival' in str(platform.window.location.search)
    app=BrowserApp(festival=festival)
    if IS_WEB:
        platform.window.parent.postMessage('pulse-breaker:ready','*')
    clock=pygame.time.Clock()
    while app.running:
        # No synchronous delay: the browser gets control at every frame.
        dt=min(.05,clock.tick()/1000)
        for event in pygame.event.get():app.handle(event)
        app.update(dt);app.draw()
        await asyncio.sleep(0)
    pygame.quit()


asyncio.run(main())
