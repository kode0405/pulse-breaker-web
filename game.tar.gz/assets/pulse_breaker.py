"""PULSE BREAKER — offline pygame arena action. Arrow keys are the movement keys."""
from __future__ import annotations
import argparse
import array
import json
import math
import os
from pathlib import Path
import random
import sys
import tempfile
from name_filter import name_problem, safe_name

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame as pg

V = pg.Vector2
W, H = 1280, 800
ARENA = pg.Rect(54, 128, 1172, 590)
MINT, BLUE, PINK, GOLD = (110, 244, 215), (113, 208, 255), (255, 116, 161), (255, 206, 111)
WHITE, MUTED = (230, 239, 245), (133, 156, 174)
STEP = 1 / 120
STAGES = [('01 / NEON HUNT', '돌진 보스 램 · 경고선을 보고 옆으로 피하세요', MINT),
          ('02 / LASER DANCE', '레이저 보스 프리즘 · 충전 중 공격하세요', (198, 151, 255)),
          ('03 / BOSS RIOT', '스펙터 · 순간이동 위치와 탄막 틈을 읽으세요', (255, 168, 117)),
          ('04 / ION STORM', '볼텍스 · 회전 탄막을 따라 빈 공간으로 이동', (99, 190, 255)),
          ('05 / ZERO HOUR', '오버로드 · 교차 포격과 연속 탄막 최종전', (255, 91, 111))]
BOSS_NAMES = {'ram':'RAM / 램', 'prism':'PRISM / 프리즘', 'specter':'SPECTER / 스펙터',
              'vortex':'VORTEX / 볼텍스', 'overlord':'OVERLORD / 오버로드', 'core':'CORE'}
BOSS_VARIANTS = ('ram','prism','specter','vortex','overlord')
BOSS_BASE_HP = (210, 225, 240, 280, 300)
# Keep bosses within four complete laser hits, including later endless rounds.
BOSS_HP_CAP = (327, 327, 327, 436)
FINAL_STAGE = len(STAGES)
SAVE_FILE = 'records-endless.json'
CHARACTERS = [
    ('펄스', '정밀 반사에 특화된 요격기', MINT, [(1.35,0),(-1,.8),(-.55,0),(-1,-.8)]),
    ('레이븐', '관통 대시를 구사하는 스텔스기', (190,160,255), [(1.35,0),(-1,1.05),(-.65,.25),(-1.2,0),(-.65,-.25),(-1,-1.05)]),
    ('타이탄', '중량 관통포를 갖춘 중장갑 기체', GOLD, [(1.25,.38),(.35,.38),(.1,.85),(-1,.85),(-1,-.85),(.1,-.85),(.35,-.38),(1.25,-.38)]),
    ('노바', '충전 레이저에 특화된 에너지 기체', (255,151,194), [(1.35,0),(.25,.3),(0,1),(-.3,.3),(-1,0),(-.3,-.3),(0,-1),(.25,-.3)]),
]
ABILITIES = ['반사 성공 → 충격파 3 피해 (재사용 3초)', '대시로 관통 공격 · 적마다 4 피해',
             '체력 7 · 보호막이 없으면 12초 후 재생', '고속 충전 · 강화 레이저 + 발사 시 주변 폭발']
WEAPONS = ['정밀 단발', '평행 쌍발', '중량 관통포', '3갈래 확산탄']
PRACTICE_LESSONS = [('MOVE + FIRE', '방향키로 이동하고, 마우스로 첫 목표를 겨냥해 좌클릭!'),
                    ('DASH', '방향키 + Shift로 무적 대시를 한 번 사용하세요.'),
                    ('REFLECT', '다가오는 탄환에 우클릭 / E로 반사하세요. 피해는 없습니다.'),
                    ('CHARGE LASER', '표시된 목표에 좌클릭을 유지해 충전 레이저를 맞히세요.')]
GIMMICK_NAMES = ('가속 레일 · 이동 +16%', '이동 방벽 · 탄환 차단 / 대시로 통과',
                '중력 우물 · 당기는 힘을 읽으세요', '이온 펄스 · 원 밖으로 회피', '과부하 구역 · 폭발 전에 탈출')


def unit(v, fallback=(1, 0)):
    v = V(v)
    return v.normalize() if v.length_squared() > 0.00001 else V(fallback)


def segment_distance(a, b, p):
    d = b - a
    t = max(0, min(1, (p - a).dot(d) / d.length_squared())) if d.length_squared() else 0
    return (a + d * t - p).length()

def laser_normal(axis):
    return {'x':V(1,0),'y':V(0,1),'d1':V(1,1).normalize(),'d2':V(1,-1).normalize()}[axis]

def laser_ends(axis, coord):
    normal = laser_normal(axis)
    side = V(-normal.y,normal.x)
    center = normal*coord
    clipped = ARENA.inflate(-8,-8).clipline(center-side*3000, center+side*3000)
    return (V(clipped[0]),V(clipped[1])) if clipped else (center,center+side)


class World:
    """Fixed-step simulation independent from display, sound, storage, and frame rate."""
    def __init__(self, opening=False, festival=False, character=0, practice=False):
        self.character = character if character in range(4) else 0
        self.max_hp = (5,4,7,4)[self.character]
        self.move_speed = (320,380,270,320)[self.character]
        self.dash_cooldown = .8 if self.character == 1 else 1.15
        self.parry_cooldown = .75 if self.character == 0 else 1.05
        self.charge_duration = .9 if self.character == 3 else 1.35
        self.festival = festival
        self.practice = practice
        self.practice_step = 0
        self.practice_marks = [False]*4
        self.practice_baseline = 0
        self.practice_shot_left = .8
        self.beams_fired = 0
        self.near_misses = 0
        self.graze_cd = self.charge_bonus = self.charge_bonus_left = 0.0
        self.gimmicks = []
        self.gimmick_state = None
        self.supply_left = 0.0
        self.finish_reason = ''
        self.rng = random.Random(8127)
        self.time = 0.0
        self.pos, self.vel, self.aim = V(640, 423), V(), V(1, 0)
        self.hp = self.max_hp
        self.score = self.kills = self.streak = self.best_streak = self.reflected = 0
        self.combo_left = self.invulnerable = 0.0
        self.dash_cd = self.dash_time = self.parry_cd = self.parry_time = self.shot_cd = 0.0
        self.dash_buffer = self.parry_buffer = 0.0
        self.dash_dir = V(1, 0)
        self.spawn_left = 0.65
        self.enemies, self.bullets, self.events = [], [], []
        self.done = False
        self.boss_spawned = False
        self.stage_bosses = set()
        self.phase = 1
        self.round = 1
        self.round_time = 0.0
        self.next_round = False
        self.next_id = 0
        self.hazards = []
        self.laser_left = 3.0
        self.laser_index = 0
        self.next_bonus = 8.0
        self.overdrive = 0.0
        self.cells = []
        self.drops = []
        self.drop_index = 0
        self.shield = 0
        self.ability_cd = 0.0
        self.armor_charge = 0.0
        self.dash_hits = set()
        self.laser_ammo = 0
        self.charge = self.beam_left = 0.0
        self.beam_dir = V(1, 0)
        self.bonus_kills = 0
        self.opening = opening
        self.first_reward = False
        self.distance_moved = 0.0
        self.shots_fired = self.dashes_used = 0
        self.goal_index = 0
        if practice:
            self.opening = False
            self.spawn_left = self.next_bonus = self.laser_left = 10000
            target = self.spawn('chaser', self.pos+V(225,0))
            target.update(hp=1,maxhp=1,spawn=.25,practice_target=True)
        elif opening:
            self.invulnerable = 5.0
            self.spawn_left = 2.8
            self.next_bonus = 5.5
            target = self.spawn('chaser', self.pos + V(225, 0))
            target.update(hp=1, maxhp=1, r=24, spawn=.35, practice=True)

    def emit(self, kind, **kwargs):
        self.events.append(dict(kind=kind, **kwargs))

    def drain(self):
        events, self.events = self.events, []
        return events

    def near_miss(self, pos):
        if self.practice or self.graze_cd>0 or self.invulnerable>0 or self.dash_time>0 or self.parry_time>0:
            return
        self.near_misses += 1
        self.score += 75
        self.graze_cd = .35
        self.charge_bonus = min(.35,self.charge_bonus+.08)
        self.charge_bonus_left = 6.0
        self.emit('near_miss',pos=V(pos),bonus=self.charge_bonus)

    @staticmethod
    def wall_push(point, radius, rect):
        bounds=rect.inflate(radius*2,radius*2)
        if bounds.collidepoint(point):
            edges=[(abs(point.x-bounds.left),V(bounds.left,point.y)),
                   (abs(point.x-bounds.right),V(bounds.right,point.y)),
                   (abs(point.y-bounds.top),V(point.x,bounds.top)),
                   (abs(point.y-bounds.bottom),V(point.x,bounds.bottom))]
            return min(edges,key=lambda edge:edge[0])[1]
        return point

    def arena_rules(self, dt, previous_pos):
        self.gimmicks=[]
        if self.practice:
            return
        local=self.round_time-(self.phase-1)*(12 if self.festival else 30)
        if self.phase==1:
            self.gimmicks=[dict(kind='rail',rect=pg.Rect(x,160,90,525)) for x in (275,915)]
        elif self.phase==2:
            self.gimmicks=[dict(kind='wall',rect=pg.Rect(x,int(335+math.sin(local*.65+i*math.pi)*130),36,150))
                           for i,x in enumerate((360,884))]
            if self.dash_time<=0:
                for item in self.gimmicks:
                    self.pos=self.wall_push(self.pos,17,item['rect'])
        elif self.phase==3:
            center=V(640+math.cos(local*.35)*150,423+math.sin(local*.35)*105)
            self.gimmicks=[dict(kind='gravity',pos=center,r=170)]
            delta=center-self.pos
            distance=delta.length()
            if 1<distance<170 and self.dash_time<=0:
                self.pos+=unit(delta)*85*(1-distance/170)*dt
        else:
            period=8 if self.phase==4 else 6
            age=local%period
            warn,active=1.8,1.2
            state='warning' if 3<=age<3+warn else 'active' if 3+warn<=age<3+warn+active else 'idle'
            points=(V(400,325),V(880,535)) if int(local//period)%2==0 else (V(400,535),V(880,325))
            marker=(self.round,self.phase,int(local//period),state)
            if marker!=self.gimmick_state:
                self.gimmick_state=marker
                if state!='idle':
                    for point in points[:1 if self.phase==4 else 2]:
                        self.emit('gimmick_warning' if state=='warning' else 'gimmick_fire',pos=point.copy())
            for point in points[:1 if self.phase==4 else 2]:
                self.gimmicks.append(dict(kind='pulse',pos=point,r=105,state=state,progress=(age-3)/warn))
                if state=='active' and segment_distance(previous_pos,self.pos,point)<=122:
                    self.hurt()
        self.pos.x=max(ARENA.left+17,min(ARENA.right-17,self.pos.x))
        self.pos.y=max(ARENA.top+17,min(ARENA.bottom-17,self.pos.y))

    def update_practice(self, dt):
        if self.practice_step==0:
            passed=self.kills>0 and self.shots_fired>0 and self.distance_moved>=80
        elif self.practice_step==1:
            passed=self.dashes_used>self.practice_baseline
        elif self.practice_step==2:
            passed=self.reflected>self.practice_baseline
            self.practice_shot_left-=dt
            if self.practice_shot_left<=0:
                self.practice_shot_left=2.0
                source=V(min(ARENA.right-35,self.pos.x+400),self.pos.y)
                if (source-self.pos).length()<150:
                    source=V(max(ARENA.left+35,self.pos.x-400),self.pos.y)
                self.shoot(source,unit(self.pos-source),False,210)
        else:
            passed=self.beams_fired>self.practice_baseline and not any(e.get('laser_target') for e in self.enemies)
            if self.laser_ammo==0 and self.beam_left<=0 and not passed:
                self.laser_ammo=1
                self.emit('practice_refill')
        if passed:
            self.practice_marks[self.practice_step]=True
            self.practice_step+=1
            self.enemies.clear();self.bullets.clear();self.cells.clear();self.drops.clear()
            self.charge=self.beam_left=0
            if self.practice_step==4:
                self.done=True;self.finish_reason='practice_complete';self.emit('finish')
                return
            self.practice_baseline=(0,self.dashes_used,self.reflected,self.beams_fired)[self.practice_step]
            if self.practice_step==3:
                self.laser_ammo=1
                offset=225 if self.pos.x<ARENA.centerx else -225
                target=self.spawn('bruiser',(max(ARENA.left+40,min(ARENA.right-40,self.pos.x+offset)),self.pos.y))
                target.update(hp=55,maxhp=55,spawn=.25,practice_target=True,laser_target=True)
            self.emit('practice_lesson',lesson=self.practice_step)
        if self.time>=45 and not self.done:
            self.done=True;self.finish_reason='practice_time';self.emit('finish')

    def spawn(self, kind=None, pos=None):
        if kind is None:
            roll = self.rng.random()
            kind = 'chaser' if self.time < 10 or roll < .48 else 'shooter' if roll < .83 or self.time < 25 else 'bruiser'
            if self.time >= 12 and roll < .32:
                kind = ('weaver','sniper','spinner')[int(self.time//6)%3]
            if self.phase>=4 and roll<.5:
                kind = 'spinner' if self.phase==4 else 'sniper' if roll<.25 else 'bruiser'
        if pos is None:
            candidates = [V(96, 170), V(640, 170), V(1184, 170), V(96, 674), V(640, 674), V(1184, 674)]
            self.rng.shuffle(candidates)
            pos = max(candidates[:4], key=lambda p: (p - self.pos).length_squared())
        hp, radius = {'chaser': (2, 15), 'shooter': (3, 19), 'bruiser': (6, 24), 'boss': (75, 44), 'drone': (2, 17), 'weaver': (3,17), 'sniper': (4,20), 'spinner': (5,23)}[kind]
        if kind != 'drone':
            hp = math.ceil(hp * (1 + .10 * min(10, self.round - 1)))
        self.next_id += 1
        enemy = dict(id=self.next_id, kind=kind, pos=V(pos), hp=hp, maxhp=hp, r=radius,
                     spawn=1.05 if kind != 'boss' else 1.65, cd=1.0, warn=False, aim=V(-1, 0),
                     rush=0.0, shots=0, hit=0.0, rage=False, age=0.0)
        self.enemies.append(enemy)
        self.emit('spawn', pos=V(pos), boss=kind == 'boss')
        return enemy

    def shoot(self, pos, direction, friendly, speed=760, damage=1, reflected=False):
        if len(self.bullets) >= 240:
            return
        self.bullets.append(dict(pos=V(pos), vel=unit(direction) * speed, friendly=friendly,
                                 damage=damage, r=5 if reflected else 3 if friendly else 6,
                                 life=1.65 if friendly else 5.0, reflected=reflected))
        return self.bullets[-1]

    def hurt(self):
        if self.practice or self.done or self.invulnerable > 0 or self.dash_time > 0 or self.parry_time > 0:
            return
        if self.shield:
            self.shield = 0
            self.invulnerable = 1.0
            self.emit('shield_break', pos=self.pos.copy())
            return
        self.hp = max(0, self.hp - 1)
        self.invulnerable = 1.0
        self.streak = 0
        self.combo_left = 0
        self.emit('hurt', pos=self.pos.copy())
        if self.hp <= 0:
            self.finish_reason = 'defeat'
            self.done = True
            self.emit('finish')

    def kill(self, enemy):
        self.kills += 1
        self.streak += 1
        self.best_streak = max(self.best_streak, self.streak)
        self.combo_left = 4.0
        mult = min(4, 1 + self.streak // 5)
        value = {'chaser': 100, 'shooter': 180, 'bruiser': 300, 'boss': 2500, 'drone': 400, 'weaver':160, 'sniper':240, 'spinner':280}[enemy['kind']] * mult
        if self.overdrive > 0:
            value *= 2
        self.score += value
        if self.kills % 5 == 0:
            kind = ('repair', 'shield', 'nova')[self.drop_index % 3]
            self.drop_index += 1
            self.drops.append(dict(kind=kind, pos=enemy['pos'].copy(), life=16.0))
            self.drops = self.drops[-6:]
        self.emit('kill', pos=enemy['pos'].copy(), score=value, boss=enemy['kind'] == 'boss',
                  stage_boss=enemy.get('stage_boss',FINAL_STAGE), variant=enemy.get('variant','core'))
        if self.opening and not self.first_reward:
            self.first_reward = True
            self.overdrive = max(self.overdrive, 4.0)
            self.dash_cd = self.parry_cd = 0
            self.emit('first_blood', pos=enemy['pos'].copy())
        if enemy['kind'] == 'drone':
            self.cells.append(dict(pos=enemy['pos'].copy(), life=18.0))
            self.cells = self.cells[-4:]
            if enemy.get('supply'):
                self.emit('supply_down',pos=enemy['pos'].copy())
            else:
                self.bonus_kills += 1
                self.overdrive = 6.0
                self.dash_cd = self.parry_cd = 0
                self.emit('overdrive', pos=self.pos.copy())
        if enemy['kind'] == 'boss':
            self.bullets = [b for b in self.bullets if b['friendly']]
            self.hazards.clear()
            self.hp = min(self.max_hp, self.hp + 1)
            self.overdrive = 8.0 if enemy.get('stage_boss',FINAL_STAGE)==FINAL_STAGE else 5.0
            self.invulnerable = max(self.invulnerable,1.8)
            self.dash_cd = self.parry_cd = 0
            self.cells.append(dict(pos=enemy['pos'].copy(),life=18.0))
            self.cells = self.cells[-4:]
            if enemy.get('stage_boss',FINAL_STAGE)==FINAL_STAGE:
                self.next_round = True
        if self.kills % 15 == 0 and 0 < self.hp < self.max_hp:
            self.hp += 1
            self.emit('heal', pos=self.pos.copy())

    def step(self, dt, movement=(0, 0), aim=(1, 0), fire=False, dash=False, parry=False):
        if self.done or not math.isfinite(dt) or dt <= 0:
            return
        dt = min(dt, .05)
        if self.practice:
            dt=min(dt,max(0,45-self.time))
        elif self.festival:
            dt = min(dt, max(0, 60-self.time))
        self.time += dt
        self.round_time += dt
        self.graze_cd=max(0,self.graze_cd-dt)
        self.charge_bonus_left=max(0,self.charge_bonus_left-dt)
        if self.charge_bonus_left<=0:
            self.charge_bonus=0
        self.ability_cd = max(0, self.ability_cd-dt)
        if self.character == 2:
            if self.shield:
                self.armor_charge = 0
            else:
                self.armor_charge += dt
                if self.armor_charge >= 12:
                    self.shield = 1
                    self.armor_charge = 0
                    self.emit('ability', ability='armor', pos=self.pos.copy())
        pressure = min(6, self.time / 180 + (self.round - 1) * .25)
        self.aim = unit(aim, self.aim)
        movement = V(movement)
        if movement.length_squared() > 1:
            movement.normalize_ip()
        if dash:
            self.dash_buffer = .12
        if parry:
            self.parry_buffer = .12
        for key in ['dash_cd', 'dash_time', 'parry_cd', 'parry_time', 'shot_cd', 'invulnerable', 'combo_left', 'overdrive']:
            setattr(self, key, max(0.0, getattr(self, key) - dt))
        if self.combo_left == 0:
            self.streak = 0
        if self.dash_buffer > 0 and self.dash_cd <= 0:
            self.dashes_used += 1
            self.dash_hits.clear()
            self.dash_dir = unit(movement, self.aim)
            self.dash_time, self.dash_cd, self.dash_buffer = .18, self.dash_cooldown, 0
            self.emit('dash', pos=self.pos.copy())
        if self.parry_buffer > 0 and self.parry_cd <= 0:
            self.parry_time, self.parry_cd, self.parry_buffer = .22, self.parry_cooldown, 0
            self.emit('parry', pos=self.pos.copy())
            for e in self.enemies:
                if e['spawn'] <= 0 and not e.get('laser_target') and (e['pos'] - self.pos).length() <= 92 + e['r']:
                    e['hp'] -= 2
                    e['hit'] = .1
                    e['pos'] += unit(e['pos'] - self.pos) * (12 if e['kind'] == 'boss' else 48)
        self.dash_buffer = max(0, self.dash_buffer - dt)
        self.parry_buffer = max(0, self.parry_buffer - dt)
        if self.dash_time > 0:
            self.vel = self.dash_dir * 1020
        else:
            on_rail=not self.practice and self.phase==1 and any(pg.Rect(x,160,90,525).collidepoint(self.pos) for x in (275,915))
            target = movement * self.move_speed * (1.16 if on_rail else 1)
            self.vel += (target - self.vel) * (1 - math.exp(-30 * dt))
        previous_pos = self.pos.copy()
        self.pos += self.vel * dt
        self.pos.x = max(ARENA.left + 17, min(ARENA.right - 17, self.pos.x))
        self.pos.y = max(ARENA.top + 17, min(ARENA.bottom - 17, self.pos.y))
        self.distance_moved += (self.pos - previous_pos).length()
        if self.character == 1 and self.dash_time > 0:
            for enemy in self.enemies:
                if enemy['spawn'] <= 0 and enemy['hp'] > 0 and not enemy.get('laser_target') and enemy['id'] not in self.dash_hits and segment_distance(previous_pos,self.pos,enemy['pos']) <= enemy['r']+20:
                    enemy['hp'] -= 4
                    enemy['hit'] = .15
                    self.dash_hits.add(enemy['id'])
                    self.emit('ability', ability='blade', pos=enemy['pos'].copy())
        self.beam_left = max(0, self.beam_left-dt)
        for cell in self.cells:
            cell['life'] -= dt
            if (cell['pos']-self.pos).length() < 160:
                cell['pos'] += unit(self.pos-cell['pos'])*min(300*dt, (cell['pos']-self.pos).length())
            if self.laser_ammo < 2 and (cell['pos']-self.pos).length() < 30:
                self.laser_ammo += 1
                cell['life'] = 0
                self.emit('cell')
        self.cells = [c for c in self.cells if c['life'] > 0]
        for drop in self.drops:
            drop['life'] -= dt
            delta = self.pos-drop['pos']
            if delta.length() < 160:
                drop['pos'] += unit(delta)*min(300*dt, delta.length())
            if (drop['pos']-self.pos).length() < 30:
                drop['life'] = 0
                kind = drop['kind']
                bonus = 0
                if kind == 'repair':
                    if self.hp == self.max_hp:
                        bonus = 300
                    self.hp = min(self.max_hp, self.hp+1)
                elif kind == 'shield':
                    if self.shield:
                        bonus = 300
                    self.shield = 1
                elif kind == 'nova':
                    self.bullets = [b for b in self.bullets if b['friendly'] or (b['pos']-self.pos).length() > 320]
                    for enemy in self.enemies:
                        if enemy['spawn'] <= 0 and enemy['hp'] > 0 and (enemy['pos']-self.pos).length() <= 320+enemy['r']:
                            enemy['hp'] -= 12
                            enemy['hit'] = .15
                self.score += bonus
                self.emit('pickup', pickup=kind, bonus=bonus, pos=self.pos.copy())
        self.drops = [d for d in self.drops if d['life'] > 0]
        if fire and self.laser_ammo > 0 and self.beam_left <= 0:
            if self.charge == 0:
                self.emit('beam_charge')
            self.charge += dt*(1+self.charge_bonus)
            if self.charge >= self.charge_duration:
                self.charge = 0
                self.laser_ammo -= 1
                self.beam_left = 1.4
                self.beam_dir = self.aim.copy()
                self.beams_fired+=1
                self.charge_bonus=self.charge_bonus_left=0
                self.emit('beam_fire')
                if self.character == 3:
                    for enemy in self.enemies:
                        if enemy['spawn'] <= 0 and enemy['hp'] > 0 and (enemy['pos']-self.pos).length() <= 180+enemy['r']:
                            enemy['hp'] -= 8
                            enemy['hit'] = .15
                    self.emit('ability', ability='nova', pos=self.pos.copy())
        elif self.charge > 0:
            self.charge = 0
            self.emit('beam_cancel')
        if fire and self.shot_cd <= 0 and self.charge <= 0 and self.beam_left <= 0:
            self.shots_fired += 1
            boosted = self.overdrive > 0
            self.shot_cd = ((.18,.22,.44,.28) if boosted else (.22,.28,.58,.36))[self.character]
            patterns = [(-8,0,8) if boosted else (0,), (-5,0,5) if boosted else (0,),
                        (-7,0,7) if boosted else (0,), (-22,-11,0,11,22) if boosted else (-14,0,14)]
            for angle in patterns[self.character]:
                for offset in (-8,8) if self.character == 1 else (0,):
                    side = V(-self.aim.y,self.aim.x)
                    bullet = self.shoot(self.pos+self.aim*24+side*offset, self.aim.rotate(angle), True,
                                        (850,900,620,700)[self.character], 3 if self.character==2 else 1)
                    if bullet is not None:
                        bullet.update(weapon=self.character, r=6 if self.character==2 else 3,
                                      pierce=3 if self.character==2 else 1, hit_ids=set())
            self.emit('shot', pos=self.pos + self.aim * 24, weapon=self.character)
        phase = 1 if self.practice else 1 + min(FINAL_STAGE-1, int(self.round_time // (12 if self.festival else 30)))
        if phase != self.phase:
            self.phase = phase
            # The timed stage transition retires an unfinished earlier boss.
            self.enemies = [e for e in self.enemies if e['kind']!='boss' and not e.get('supply')]
            self.bullets = [b for b in self.bullets if b['friendly']]
            self.hazards.clear()
            self.laser_left = 3.0
            self.invulnerable = max(self.invulnerable, 1.6)
            self.emit('phase', phase=phase)
        self.arena_rules(dt,previous_pos)
        if self.done:
            return
        if not self.practice and self.time >= self.next_bonus:
            self.next_bonus += 15
            if len(self.enemies) < min(18, 12 + self.round):
                self.spawn('drone')
                self.emit('bonus')
        if not self.practice and self.phase >= 2:
            self.laser_left -= dt
            if self.laser_left <= 0:
                self.laser_left += max(4.8, 7.2-self.phase*.3-pressure*.15)
                axis = ('x','d1','y','d2')[self.laser_index % 4]
                self.laser_index += 1
                normal = laser_normal(axis)
                coord = self.pos.dot(normal)
                center = V(ARENA.center).dot(normal)
                speed = (120 if coord < center else -120) if self.laser_index % 4 in (2, 3) else 0
                lower, upper = (ARENA.left+40, ARENA.right-40) if axis=='x' else (ARENA.top+40, ARENA.bottom-40)
                if axis.startswith('d'):
                    projected = [V(c).dot(normal) for c in (ARENA.topleft,ARENA.topright,ARENA.bottomleft,ARENA.bottomright)]
                    lower,upper = min(projected)+120,max(projected)-120
                center_pair = max(lower+110,min(upper-110,coord))
                lanes = (coord,) if self.phase==2 else (center_pair-110,center_pair+110)
                for lane in lanes if len(self.hazards)<3 else ():
                    self.hazards.append(dict(axis=axis,coord=lane,speed=speed,
                                             age=0.0,warn=1.4,active=1.9,hit=False))
                if self.phase>=4 and len(self.hazards)<4:
                    cross_axis='d2' if axis in ('x','d1') else 'd1'
                    self.hazards.append(dict(axis=cross_axis,coord=self.pos.dot(laser_normal(cross_axis)),speed=0,
                                             age=0.,warn=1.4,active=1.9,hit=False))
                self.emit('laser_warning')
        for h in self.hazards:
            old_coord = h['coord']
            old_age = h['age']
            h['age'] += dt
            active_dt = max(0, min(h['age']-h['warn'], h['active']))-max(0, min(old_age-h['warn'], h['active']))
            lower, upper = (ARENA.left+28, ARENA.right-28) if h['axis']=='x' else (ARENA.top+28, ARENA.bottom-28)
            normal = laser_normal(h['axis'])
            if h['axis'].startswith('d'):
                projected = [V(c).dot(normal) for c in (ARENA.topleft,ARENA.topright,ARENA.bottomleft,ARENA.bottomright)]
                lower,upper = min(projected)+70,max(projected)-70
            h['coord'] = max(lower, min(upper, h['coord']+h.get('speed',0)*active_dt))
            if h['warn'] <= h['age'] < h['warn'] + h['active']:
                if not h['hit']:
                    h['hit'] = True
                    self.emit('laser_fire', axis=h['axis'], coord=h['coord'])
                before = previous_pos.dot(normal)-old_coord
                after = self.pos.dot(normal)-h['coord']
                distance = min(abs(before),abs(after)) if before*after > 0 else 0
                if distance <= 28:
                    health=(self.hp,self.shield)
                    self.hurt()
                    if health!=(self.hp,self.shield):
                        h['damaged']=True
                    if self.done:
                        return
                elif distance<=50 and self.invulnerable<=0 and self.dash_time<=0 and self.parry_time<=0:
                    h['near']=True
                if h.get('near') and not h.get('damaged') and not h.get('grazed') and abs(after)>50:
                    h['grazed']=True
                    self.near_miss(self.pos)
            if h['age']>=h['warn']+h['active'] and h.get('near') and not h.get('damaged') and not h.get('grazed'):
                h['grazed']=True
                self.near_miss(self.pos)
        self.hazards = [h for h in self.hazards if h['age'] < h['warn'] + h['active']]
        self.spawn_left -= dt
        if not self.practice and self.spawn_left <= 0:
            fighting_boss = any(e['kind']=='boss' for e in self.enemies)
            self.spawn_left += max(.75, 1.65 - self.phase*.10 - pressure * .05)+(.55 if fighting_boss else 0)
            if len(self.enemies) < min(18, 12 + self.round):
                self.spawn()
        boss_at = (5,17,29,41,50) if self.festival else (12,42,72,102,120)
        if (not self.practice and self.round_time >= boss_at[self.phase-1] and self.phase not in self.stage_bosses
                and not any(e['kind']=='boss' for e in self.enemies)
                and not (self.phase==FINAL_STAGE and self.boss_spawned)):
            self.stage_bosses.add(self.phase)
            self.boss_spawned = self.phase==FINAL_STAGE
            boss = self.spawn('boss')
            boss['variant'] = BOSS_VARIANTS[self.phase-1]
            boss['stage_boss'] = self.phase
            hp = math.ceil(BOSS_BASE_HP[self.phase-1]*(4/3 if self.character==3 else 1)
                           *(1+.12*min(10,self.round-1)))
            boss['hp'] = boss['maxhp'] = min(hp, BOSS_HP_CAP[self.character])
            boss['cd'] = 2.2
            self.enemies = [e for e in self.enemies if e['kind']=='boss']
            self.bullets = [b for b in self.bullets if b['friendly']]
            self.hazards.clear()
            self.laser_left = 6.0
            self.invulnerable = max(self.invulnerable,1.8)
            self.supply_left=.85 if self.festival else 1.2
            self.emit('boss',variant=boss['variant'])
        bosses=[e for e in self.enemies if e['kind']=='boss' and e['hp']>0]
        if bosses:
            self.supply_left-=dt
            if self.supply_left<=0:
                self.supply_left=2.6 if self.festival else 4.8
                if sum(bool(e.get('supply')) for e in self.enemies)<2 and len(self.enemies)<min(18,12+self.round):
                    candidates=[self.pos+offset for offset in (V(190,0),V(-190,0),V(0,155),V(0,-155))]
                    for point in candidates:
                        point.x=max(ARENA.left+35,min(ARENA.right-35,point.x))
                        point.y=max(ARENA.top+35,min(ARENA.bottom-35,point.y))
                    def safe_supply(point):
                        return not any((item['kind']=='wall' and item['rect'].inflate(60,60).collidepoint(point))
                                       or (item['kind']=='pulse' and item['state']!='idle' and (point-item['pos']).length()<item['r']+30)
                                       for item in self.gimmicks)
                    safe=[point for point in candidates if safe_supply(point)]
                    if not safe:
                        safe=[point for point in (V(130,200),V(1150,200),V(130,650),V(1150,650)) if safe_supply(point)]
                    point=max(safe or candidates,key=lambda point:(point-bosses[0]['pos']).length_squared())
                    drone=self.spawn('drone',point)
                    drone.update(hp=1,maxhp=1,spawn=.4,supply=True,supply_life=9.0,anchor=point.copy())
                    self.emit('supply',pos=point.copy())
        else:
            self.enemies=[e for e in self.enemies if not e.get('supply')]
        for e in self.enemies:
            e['hit'] = max(0, e['hit'] - dt)
            if e['hp'] <= 0:
                continue
            if e['spawn'] > 0:
                e['spawn'] = max(0, e['spawn'] - dt)
                continue
            to_player = self.pos - e['pos']
            direction = unit(to_player)
            distance = to_player.length()
            kind = e['kind']
            e['cd'] -= dt
            e['age'] += dt
            if e.get('practice_target'):
                continue
            if e.get('supply'):
                e['supply_life']-=dt
                e['pos']=e['anchor']+V(0,math.sin(e['age']*2.5)*12)
                continue
            if kind=='boss':
                if e['hp']<=e['maxhp']/2 and not e['rage']:
                    e['rage']=True
                    e['transform_left']=.9
                    self.emit('boss_transform',pos=e['pos'].copy(),variant=e.get('variant','core'))
                e['form']=2 if e['rage'] else 1
                e['transform_left']=max(0,e.get('transform_left',0)-dt)
            if kind=='boss' and e.get('variant') in ('vortex','overlord'):
                final=e['variant']=='overlord'
                side=V(-direction.y,direction.x)
                e['pos']+=(direction*(45 if distance>330 else -30 if distance<230 else 0)+side*55)*dt
                if e['cd']<=.85 and not e['warn']:
                    e['warn'],e['aim']=True,direction
                if e['cd']<=0:
                    e['shots']+=1
                    rotation=e['shots']*17
                    angles = range(-36,37,9 if e['rage'] else 12) if final and e['shots']%2 else [angle+rotation for angle in range(0,360,24 if e['rage'] else 30)]
                    for angle in angles:
                        d=e['aim'].rotate(angle)
                        self.shoot(e['pos']+d*56,d,False,280 if e['rage'] else 235)
                    if final and e['shots']%(2 if e['rage'] else 3)==0 and len(self.hazards)<3:
                        for axis in ('d1','d2'):
                            self.hazards.append(dict(axis=axis,coord=self.pos.dot(laser_normal(axis)),speed=0,
                                                     age=0.,warn=1.4,active=1.9,hit=False))
                        self.emit('laser_warning')
                    e['cd'],e['warn']=(1.6 if e['rage'] else 2.0),False
            elif kind == 'boss' and e.get('variant')=='ram':
                if e['rush']>0:
                    e['rush']=max(0,e['rush']-dt)
                    e['pos']+=e['aim']*(570 if e['rage'] else 510)*dt
                    if e['rush']==0 and e['rage']:
                        for angle in range(0,360,45):
                            self.shoot(e['pos']+V(1,0).rotate(angle)*55,V(1,0).rotate(angle),False,180)
                elif e['cd']>.95:
                    e['pos']+=direction*55*dt
                if e['cd']<=.95 and not e['warn']:
                    e['warn'],e['aim']=True,direction
                if e['cd']<=0:
                    e['rush'],e['cd'],e['warn']=.45,(1.9 if e['rage'] else 2.5),False
                    for angle in range(-36,37,12) if e['rage'] else (-24,-12,0,12,24):
                        d=e['aim'].rotate(angle)
                        self.shoot(e['pos']+d*55,d,False,190)
            elif kind == 'boss' and e.get('variant')=='prism':
                side=V(-direction.y,direction.x)
                e['pos']+=side*30*dt
                if e['cd']<=1.1 and not e['warn']:
                    e['warn'],e['aim']=True,direction
                if e['cd']<=0:
                    e['shots']+=1
                    for angle in (-30,-15,0,15,30) if e['rage'] else (-20,0,20):
                        d=e['aim'].rotate(angle)
                        self.shoot(e['pos']+d*55,d,False,210)
                    if len(self.hazards)<(3 if e['rage'] else 2):
                        axes=('d1','d2') if e['rage'] else (('x','d1','y','d2')[e['shots']%4],)
                        for axis in axes:
                            self.hazards.append(dict(axis=axis,coord=self.pos.dot(laser_normal(axis)),speed=0,
                                                     age=0.,warn=1.4,active=1.9,hit=False))
                        self.emit('laser_warning')
                    e['cd'],e['warn']=(2.5 if e['rage'] else 3.0),False
            elif kind == 'boss' and e.get('variant') == 'specter':
                if e['cd'] <= 1.0 and not e['warn']:
                    e['warn'],e['aim'] = True,direction
                    candidates = [V(180,230),V(1100,230),V(180,610),V(1100,610)]
                    e['teleport'] = max(candidates,key=lambda point:(point-self.pos).length_squared()+(point-e['pos']).length_squared()*.4)
                if e['cd'] <= 0:
                    e['pos'] = e.pop('teleport',e['pos']).copy()
                    e['shots'] += 1
                    aim = unit(self.pos-e['pos'])
                    angles = range(0,360,30 if e['rage'] else 36) if e['shots']%2==0 else (-36,-24,-12,0,12,24,36) if e['rage'] else (-30,-15,0,15,30)
                    for angle in angles:
                        d=aim.rotate(angle)
                        bullet=self.shoot(e['pos']+d*56,d,False,270 if e['rage'] else 220)
                        if bullet is not None:
                            bullet['bone']=True
                            bullet['r']=9
                    if e['shots']%3==0 and len(self.hazards)<3:
                        axis='d1' if (e['shots']//2)%2 else 'd2'
                        self.hazards.append(dict(axis=axis,coord=self.pos.dot(laser_normal(axis)),speed=0,age=0.,warn=1.4,active=1.9,hit=False))
                        self.emit('laser_warning')
                    self.emit('blink',pos=e['pos'].copy())
                    e['cd'],e['warn'] = (1.8 if e['rage'] else 2.2),False
            elif kind == 'drone':
                target = V(640 + math.cos(e['age'] * 1.3 + e['id']) * 365,
                           423 + math.sin(e['age'] * 1.8 + e['id']) * 175)
                e['pos'] += unit(target - e['pos']) * 210 * dt
            elif kind == 'weaver':
                side = V(-direction.y,direction.x)
                e['pos'] += (direction*150+side*math.sin(e['age']*7)*160)*dt
            elif kind in ('sniper','spinner'):
                warning = .9 if kind=='sniper' else .7
                if e['cd'] > warning:
                    e['pos'] += direction*(65 if distance>400 else -45 if distance<260 else 0)*dt
                if e['cd'] <= warning and not e['warn']:
                    e['warn'],e['aim'] = True,direction
                if e['cd'] <= 0:
                    angles = (0,) if kind=='sniper' else range(0,360,60)
                    for angle in angles:
                        d=e['aim'].rotate(angle)
                        self.shoot(e['pos']+d*(e['r']+8),d,False,310 if kind=='sniper' else 160)
                    e['cd'],e['warn'] = (3.4 if kind=='sniper' else 3.0),False
            elif kind == 'chaser':
                if not e.get('practice') or self.time > 8:
                    e['pos'] += direction * min(205, 105 + self.phase * 12 + pressure * 7) * dt
            elif kind == 'bruiser':
                if e['rush'] > 0:
                    e['rush'] -= dt
                    e['pos'] += e['aim'] * 470 * dt
                elif e['cd'] > .55:
                    e['pos'] += direction * 72 * dt
                if e['cd'] <= .55 and not e['warn']:
                    e['warn'], e['aim'] = True, direction
                if e['cd'] <= 0:
                    e['rush'], e['cd'], e['warn'] = .35, 2.05, False
            else:
                if kind == 'boss' and e['hp'] <= e['maxhp'] / 2 and not e['rage']:
                    e['rage'] = True
                    e['cd'] = 1.35
                    e['warn'] = False
                    self.emit('rage', pos=e['pos'].copy())
                desired = 340 if kind == 'boss' else 290
                forward = 1 if distance > desired + 50 else -1 if distance < desired - 50 else 0
                side = V(-direction.y, direction.x) * (1 if e['id'] % 2 else -1)
                e['pos'] += (direction * forward * (45 if kind == 'boss' else 90) + side * 28) * dt
                if e['cd'] <= .4 and not e['warn']:
                    e['warn'], e['aim'] = True, direction
                if e['cd'] <= 0:
                    e['shots'] += 1
                    angles = list(range(-27, 28, 9)) if e['rage'] else [-18, -9, 0, 9, 18] if kind == 'boss' else [-7, 7] if self.phase >= 2 else [0]
                    if kind == 'boss' and e['shots'] % (2 if e['rage'] else 4) == 0:
                        angles = [a + e['shots'] * 7 for a in range(0, 360, 24 if e['rage'] else 30)]
                    for angle in angles:
                        d = e['aim'].rotate(angle)
                        speed = min(280, (250 if e['rage'] else 180 + self.phase * 12) + pressure * 7)
                        self.shoot(e['pos'] + d * (e['r'] + 9), d, False, speed)
                    e['cd'], e['warn'] = (.76 if e['rage'] else .95 if kind == 'boss' else 1.9), False
            e['pos'].x = max(ARENA.left + e['r'], min(ARENA.right - e['r'], e['pos'].x))
            e['pos'].y = max(ARENA.top + e['r'], min(ARENA.bottom - e['r'], e['pos'].y))
            if e['rush']<=0:
                for item in self.gimmicks:
                    if item['kind']=='wall':
                        e['pos']=self.wall_push(e['pos'],e['r'],item['rect'])
            if kind != 'drone' and e['hp'] > 0 and (e['pos'] - self.pos).length() < e['r'] + 13:
                self.hurt()
                if self.done:
                    return
        if self.beam_left > 0:
            end = self.pos+self.beam_dir*1600
            for e in self.enemies:
                if e['spawn'] <= 0 and e['hp'] > 0 and segment_distance(self.pos, end, e['pos']) <= e['r']+28:
                    e['hp'] -= (80 if self.character == 3 else 60)*dt
                    e['hit'] = .08
            self.bullets = [b for b in self.bullets if b['friendly'] or segment_distance(self.pos, end, b['pos']) > 34]
        new_bullets, survivors = [], []
        for b in self.bullets:
            old = b['pos'].copy()
            b['pos'] += b['vel'] * dt
            b['life'] -= dt
            if b['life'] <= 0:
                continue
            if any(item['kind']=='wall' and item['rect'].inflate(b['r']*2,b['r']*2).clipline(old,b['pos']) for item in self.gimmicks):
                self.emit('wall_hit',pos=b['pos'].copy())
                continue
            if not b['friendly']:
                distance = segment_distance(old-previous_pos,b['pos']-self.pos,V())
                if self.parry_time > 0 and distance <= 94:
                    targets = [e for e in self.enemies if e['spawn'] <= 0 and e['hp'] > 0]
                    direction = unit(min(targets, key=lambda e: (e['pos'] - old).length_squared())['pos'] - old) if targets else self.aim
                    new_bullets.append(dict(pos=old, vel=direction * 820, friendly=True, damage=3, r=6, life=1.8, reflected=True))
                    self.reflected += 1
                    self.score += 25
                    self.emit('reflect', pos=old)
                    if self.character == 0 and self.ability_cd <= 0:
                        self.ability_cd = 3
                        for enemy in self.enemies:
                            if enemy['spawn'] <= 0 and enemy['hp'] > 0 and (enemy['pos']-self.pos).length() <= 150+enemy['r']:
                                enemy['hp'] -= 3
                                enemy['hit'] = .15
                        self.emit('ability', ability='pulse', pos=self.pos.copy())
                    continue
                if distance < b['r'] + 13:
                    self.hurt()
                    if self.done:
                        return
                    continue
                relative=b['pos']-self.pos
                if not b.get('grazed') and distance<=b['r']+33 and relative.dot(b['vel']-self.vel)>0:
                    b['grazed']=True
                    self.near_miss(self.pos)
            else:
                possible = [e for e in self.enemies if e['spawn'] <= 0 and e['hp'] > 0 and not e.get('laser_target') and e['id'] not in b.get('hit_ids',set()) and segment_distance(old, b['pos'], e['pos']) <= e['r'] + b['r']]
                if possible:
                    for enemy in sorted(possible, key=lambda e: (e['pos']-old).length_squared()):
                        enemy['hp'] -= b['damage']
                        enemy['hit'] = .08
                        b.setdefault('hit_ids',set()).add(enemy['id'])
                        b['pierce'] = b.get('pierce',1)-1
                        self.emit('impact', pos=enemy['pos'].copy(), reflected=b['reflected'])
                        if b['pierce'] <= 0:
                            break
                    if b['pierce'] <= 0:
                        continue
            if ARENA.inflate(40, 40).collidepoint(b['pos']):
                survivors.append(b)
        self.bullets = (survivors + new_bullets)[:240]
        living = []
        for e in self.enemies:
            if e['hp'] <= 0:
                self.kill(e)
            else:
                if not e.get('supply') or e['supply_life']>0:
                    living.append(e)
        self.enemies = living
        if self.practice:
            self.update_practice(dt)
            return
        goals = (1000, 3000, 10000)
        if self.opening and self.goal_index < len(goals) and self.score >= goals[self.goal_index]:
            self.emit('milestone', score=goals[self.goal_index])
            self.goal_index += 1
        if self.festival and not self.done and (self.next_round or self.time >= 60):
            self.done = True
            self.finish_reason = 'clear' if self.next_round else 'time'
            self.next_round = False
            self.emit('finish')
        if self.next_round and not self.done:
            self.next_round = False
            self.round += 1
            self.round_time = 0.0
            self.phase = 1
            self.boss_spawned = False
            self.stage_bosses.clear()
            self.enemies.clear()
            self.bullets = [b for b in self.bullets if b['friendly']]
            self.hazards.clear()
            self.gimmicks.clear()
            self.supply_left=0
            self.spawn_left = 1.3
            self.laser_left = 3.0
            self.invulnerable = max(2.0, self.invulnerable)
            self.emit('round', round=self.round)


class Audio:
    def __init__(self):
        self.enabled = True
        self.sounds = {}
        self.ready = bool(pg.mixer.get_init())
        if not self.ready:
            return
        pg.mixer.set_num_channels(24)
        pg.mixer.set_reserved(7)
        self.variants = {}
        self.last_play = {}
        self.sequence = {}
        for name, f, duration, volume in [('shot', 730, .045, .035), ('dash', 130, .19, .12),
             ('parry', 440, .16, .10), ('reflect', 1046, .23, .13), ('impact', 220, .055, .05),
             ('kill', 350, .13, .1), ('hurt', 75, .27, .14), ('count', 440, .10, .1),
             ('start', 880, .23, .13), ('finish', 659, .65, .14), ('heal', 784, .26, .13)]:
            self.sounds[name] = self.make(f, duration, volume)
        for name, f, duration, volume in [('stage', 196, .7, .15), ('overdrive', 988, .5, .13),
                                         ('laser', 110, .28, .12), ('rage', 82, .65, .12)]:
            self.sounds[name] = self.make(f, duration, volume)
        for i, f in enumerate([110, 131, 147, 165, 220, 262, 294, 330]):
            self.sounds['music' + str(i)] = self.make(f, .22, .025)
        for name, duration, gain in [('shot', .18, .22), ('impact', .22, .18),
                ('kill', .58, .3), ('dash', .38, .24), ('parry', .32, .2),
                ('reflect', .5, .3), ('hurt', .4, .25), ('laser', 1.4, .24),
                ('laser_charge', 1.35, .15), ('rage', .95, .3), ('boss_down', 1.2, .34)]:
            self.variants[name] = [self.texture(name, duration, gain, seed)
                                   for seed in range(3 if name in ('shot', 'impact', 'kill') else 1)]
            self.sounds[name] = self.variants[name][0]
        self.sounds['beam_charge'] = self.texture('player_charge', 1.35, .24, 0)
        self.sounds['beam_charge_nova'] = self.texture('player_charge', .9, .24, 0)
        self.sounds['beam_fire'] = self.texture('player_blast', 1.4, .4, 0)
        self.sounds['shot_twin'] = self.texture('shot', .14, .19, 1)
        self.sounds['shot_cannon'] = self.texture('kill', .32, .28, 0)
        self.sounds['shot_spread'] = self.texture('shot', .24, .22, 2)
        self.sounds['transform'] = self.texture('transform', .9, .36, 0)
        self.sounds['near_miss'] = self.texture('near_miss', .25, .22, 0)
        self.sounds['supply'] = self.make(1174,.25,.1)
        self.sounds['pulse_charge'] = self.texture('laser_windup',1.8,.14,1)
        self.sounds['pulse_blast'] = self.texture('player_blast',1.2,.26,1)
        for name, texture, duration, gain in [('laser_charge', 'laser_windup', 1.4, .24),
                                              ('laser', 'laser_blast', 1.9, .43)]:
            self.sounds[name] = self.texture(texture, duration, gain, 0)
            self.variants[name] = [self.sounds[name]]

    def texture(self, name, seconds, gain, seed):
        # Layered synthetic foley: transient, filtered air, low body and short room tail.
        sr = pg.mixer.get_init()[0]
        rng = random.Random(1701+seed)
        raw = []
        low = phase = 0.0
        for i in range(int(sr*seconds)):
            t = i/sr
            u = t/seconds
            noise = rng.uniform(-1, 1)
            low += .075*(noise-low)
            if name == 'transform':
                phase+=math.tau*(70+750*min(1,u*2)**2)/sr
                motor=math.tanh(math.sin(phase)*2)*.5*max(0,1-u*1.4)
                crash=(math.sin(math.tau*52*t)+low*3+noise*.3)*math.exp(-max(0,t-.35)*8) if t>=.35 else 0
                wave=motor+crash
            elif name == 'near_miss':
                phase+=math.tau*(900-650*u)/sr
                wave=(math.sin(phase)*.4+noise*.12)*math.sin(math.pi*u)**2
            elif name == 'player_charge':
                phase += math.tau*(110+1050*u*u)/sr
                coil = math.tanh(2*math.sin(phase+.8*math.sin(phase*2.01)))
                sparks = (noise-low)*max(0,math.sin(math.tau*(20*t+30*t*t)))**10
                wave = (coil*.7+math.sin(phase*1.5)*.25+sparks)*min(1,t/.025)*(.25+.75*u)
            elif name == 'player_blast':
                phase += math.tau*(48+170*math.exp(-t*25))/sr
                impact = (math.sin(phase)*2.2+noise*1.8)*math.exp(-t*13)
                sustain = (math.tanh(math.sin(math.tau*65*t)*2)*.85+low*3.5+noise*.22)
                sustain *= (1-math.exp(-t*30))*(.88+.12*math.sin(math.tau*24*t))
                wave = (impact+sustain)*min(1,max(0,(seconds-t)/.4))**1.2
            elif name == 'laser_windup':
                # Distorted coil whine with irregular high-voltage arcs.
                phase += math.tau*(170+900*u*u)/sr
                envelope = min(1,t/.06)*(.22+.78*u)
                buzz = math.tanh(2.6*math.sin(phase+1.1*math.sin(phase*3.01)))
                arc_gate = max(0,math.sin(math.tau*(27*t+21*t*t)))**12
                crackle = (noise-low)*( .15+1.9*arc_gate)
                coil = math.sin(phase*2.003)*.22+math.sin(math.tau*100*t)*.16
                wave = (buzz*.65+coil+crackle)*envelope
            elif name == 'laser_blast':
                # Explosive broadband snap, heavy impact and a delayed pressure thump.
                phase += math.tau*(44+150*math.exp(-t*24))/sr
                impact = math.sin(phase)*2.3*math.exp(-t*6)
                crack = noise*2.8*math.exp(-t*38)+low*5*math.exp(-t*7)
                after = max(0,t-.065)
                pressure = (math.sin(math.tau*48*after)*1.2+low*2)*math.exp(-after*12) if t >= .065 else 0
                # Keep the blast roaring, then taper the whole layer over the final half second.
                roar = (math.tanh(math.sin(math.tau*58*t)*2)*.9+
                        math.sin(math.tau*91*t)*.35+low*3.6+noise*.28)
                rumble = roar*(1-math.exp(-t*28))*(.86+.14*math.sin(math.tau*19*t))
                fade_out = min(1,max(0,(seconds-t)/.55))**1.3
                wave = (impact+crack+pressure+rumble)*fade_out
            elif name in ('kill', 'boss_down', 'hurt', 'rage'):
                decay = math.exp(-t/(seconds*.3))
                phase += math.tau*(42+85*math.exp(-t*20))/sr
                wave = (math.sin(phase)*.65+low*2.8)*decay
                wave += noise*.5*math.exp(-t*65)
            elif name in ('laser', 'laser_charge'):
                charge = name == 'laser_charge'
                phase += math.tau*((90+u*u*650) if charge else (95+12*math.sin(t*12)))/sr
                envelope = u**1.3 if charge else min(1, t/.015)*min(1, (seconds-t)/.16)
                wave = (math.sin(phase)*.5+math.sin(phase*2.01)*.2+low*.8)*envelope
                if not charge:
                    wave += noise*.45*math.exp(-t*45)
            elif name in ('parry', 'reflect', 'impact'):
                wave = sum(math.sin(math.tau*f*(1+seed*.025)*t)*a*math.exp(-t*d)
                           for f, a, d in ((620, .35, 15), (1477, .25, 24), (2381, .15, 35)))
                wave += noise*.65*math.exp(-t*90)+low*math.exp(-t*18)
            elif name == 'dash':
                envelope = math.sin(math.pi*u)**1.5
                phase += math.tau*(230-170*u)/sr
                wave = (low*3+noise*.14+math.sin(phase)*.25)*envelope
            else:
                phase += math.tau*(90+130*math.exp(-t*55))/sr
                wave = noise*.8*math.exp(-t*100)+math.sin(phase)*.65*math.exp(-t*28)
                wave += low*1.3*math.exp(-t*22)
            raw.append(wave)
        samples = array.array('h')
        delay = int(sr*.043)
        channels = pg.mixer.get_init()[2]
        for i, wave in enumerate(raw):
            if i >= delay:
                wave += raw[i-delay]*.18
            fade = min(1, i/(sr*.0015), (len(raw)-1-i)/(sr*.012))
            value = int(32700*gain*math.tanh(wave)*max(0, fade))
            samples.extend([value]*channels)
        return pg.mixer.Sound(buffer=samples)

    def make(self, freq, seconds, volume):
        samples = array.array('h')
        sr = pg.mixer.get_init()[0]
        for i in range(int(sr * seconds)):
            t = i / sr
            envelope = min(1, t / .006) * max(0, 1 - t / seconds) ** 2
            wave = math.sin(math.tau * freq * t) + .22 * math.sin(math.tau * freq * 2 * t)
            samples.extend([int(26000 * volume * envelope * wave)] * pg.mixer.get_init()[2])
        return pg.mixer.Sound(buffer=samples)

    def play(self, name):
        if self.ready and self.enabled and name in self.sounds:
            now = pg.time.get_ticks()
            cooldown = {'shot': 45, 'impact': 55, 'kill': 70}.get(name, 0)
            if now-self.last_play.get(name, -10000) < cooldown:
                return
            self.last_play[name] = now
            variants = self.variants.get(name, [self.sounds[name]])
            index = self.sequence.get(name, 0)
            self.sequence[name] = index+1
            reserved = {'laser': 0, 'laser_charge': 1, 'rage': 2, 'transform':2, 'boss_down': 2, 'reflect': 3, 'beam_fire': 5, 'beam_charge': 6, 'beam_charge_nova': 6}
            channel = pg.mixer.Channel(4 if name.startswith('music') else reserved[name]) if name.startswith('music') or name in reserved else pg.mixer.find_channel()
            if channel is not None:
                channel.play(variants[index % len(variants)])

    def stop(self):
        if self.ready:
            pg.mixer.stop()


class App:
    def __init__(self, data_dir=None, headless=False, festival=False):
        self.festival = festival
        self.save_file = 'records-event60.json' if festival else SAVE_FILE
        pg.mixer.pre_init(44100, -16, 1, 512)
        pg.init()
        self.screen = pg.display.set_mode((1280, 800), pg.RESIZABLE)
        pg.display.set_caption('PULSE BREAKER | '+('FESTIVAL 60s' if festival else 'ENDLESS SURVIVAL')+' | 방향키 액션')
        self.canvas, self.world_surface = pg.Surface((W, H)), pg.Surface((W, H))
        self.overlay = pg.Surface((W, H), pg.SRCALPHA)
        self.fonts, self.glows, self.text_images = {}, {}, {}
        self.system_font_path = str(Path(__file__).resolve().parent/'fonts'/'GothicA1-Regular.ttf') if sys.platform == 'emscripten' else (pg.font.match_font('malgungothic') or pg.font.match_font('notosanscjkkr'))
        font_root = Path(__file__).resolve().parent / 'fonts'
        def bundled(filename, fallback):
            path = font_root / filename
            return str(path) if path.is_file() else fallback
        latin_fallback = self.system_font_path if sys.platform == 'emscripten' else (pg.font.match_font('bahnschrift') or pg.font.match_font('segoeui') or self.system_font_path)
        self.font_path = bundled('GothicA1-Regular.ttf', self.system_font_path)
        self.font_bold_path = bundled('GothicA1-Bold.ttf', self.system_font_path if sys.platform == 'emscripten' else (pg.font.match_font('malgungothic',bold=True) or self.system_font_path))
        self.display_font_path = bundled('Orbitron-Medium.ttf', latin_fallback)
        self.display_bold_path = bundled('Orbitron-ExtraBold.ttf', latin_fallback)
        self.label_font_path = bundled('Rajdhani-Medium.ttf', latin_fallback)
        self.label_bold_path = bundled('Rajdhani-Bold.ttf', latin_fallback)
        self.audio = Audio()
        self.folder = Path(data_dir or Path(__file__).resolve().parent)
        self.records = []
        self.storage_ok, self.reduced = True, False
        self.character = 0
        self.load()
        self.world = World(festival=self.festival, character=self.character)
        self.state = 'menu'
        self.running = True
        self.fullscreen = False
        self.last_window = (1280, 800)
        self.keys, self.mouse_buttons = set(), set()
        self.mouse = V(860, 420)
        self.pending_dash = self.pending_parry = False
        self.acc = self.visual_time = self.count = 0.0
        self.last_count = -1
        self.particles, self.rings, self.labels, self.trails = [], [], [], []
        self.shake = self.hitstop = self.toast_left = 0.0
        self.stage_banner = self.flash = self.zoom = self.slomo = 0.0
        self.damage_tint = self.desaturation = 0.0
        self.toast = ('', '')
        self.name, self.composition, self.name_active = '', '', False
        self.name_error = ''
        self.buttons = {}
        self.saved_run = False
        self.music_beat = -1
        self.rng = random.Random(120)
        self.rank = 0
        self.scale = 1
        self.offset = V()
        self.background = self.make_background()
        self.stage_backgrounds = {1: self.background}
        for phase, color in [(2,(32,9,53,48)),(3,(48,17,8,42)),(4,(7,36,65,65)),(5,(70,7,24,72))]:
            background = self.background.copy()
            tint = pg.Surface((W, H), pg.SRCALPHA)
            tint.fill(color)
            background.blit(tint, (0, 0))
            self.stage_backgrounds[phase] = background
        self.menu_background = self.make_menu_background()
        self.hero_art = {}
        self.headless = headless

    def load(self):
        try:
            current = self.folder / self.save_file
            fallback = next((self.folder / filename for filename in
                             ('records-quickstart.json', 'records-festival.json', 'records.json')
                             if (self.folder / filename).exists()), self.folder / 'records.json')
            raw = json.loads((current if current.exists() else fallback).read_text(encoding='utf-8'))
            self.records = [r for r in raw.get('records', []) if isinstance(r, dict) and isinstance(r.get('name'), str)
                            and isinstance(r.get('score'), int) and 0 <= r['score'] < 10**15][:100] if current.exists() else []
            self.records = [dict(r, name=safe_name(r['name'])) for r in self.records]
            self.audio.enabled = bool(raw.get('sound', True))
            self.reduced = bool(raw.get('reduced', False))
            choice = raw.get('character', 0)
            self.character = choice if type(choice) is int and 0 <= choice < len(CHARACTERS) else 0
        except FileNotFoundError:
            pass
        except (ValueError, OSError, AttributeError, TypeError):
            self.storage_ok = False

    def persist(self):
        path = None
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=self.folder, suffix='.tmp', delete=False) as f:
                path = Path(f.name)
                json.dump(dict(records=self.records, sound=self.audio.enabled, reduced=self.reduced, character=self.character), f, ensure_ascii=False, indent=2)
            os.replace(path, self.folder / self.save_file)
            self.storage_ok = True
        except OSError:
            self.storage_ok = False
        finally:
            if path and path.exists():
                try:
                    path.unlink()
                except OSError:
                    pass

    def font(self, size, bold=False, latin=False, display=False):
        key=(size,bold,latin,display)
        if key not in self.fonts:
            if latin:
                if display:
                    path=self.display_bold_path if bold else self.display_font_path
                else:
                    path=self.label_bold_path if bold else self.label_font_path
            else:
                path=self.font_bold_path if bold else self.font_path
            try:
                self.fonts[key]=pg.font.Font(path,size)
            except (OSError,pg.error):
                self.fonts[key]=pg.font.Font(self.system_font_path,size)
        return self.fonts[key]

    def text(self, s, xy, size=18, color=WHITE, bold=False, center=False, surface=None, display=False, tracking=0):
        target=surface or self.canvas
        value=str(s)
        latin=value.isascii()
        display=display or (latin and size>=28)
        key=(value,size,tuple(color),bold,display,tracking)
        if key not in self.text_images:
            f=self.font(size*2,bold,latin,display)
            if tracking and latin:
                glyphs=[f.render(c,True,color) for c in value]
                width=sum(g.get_width() for g in glyphs)+int(tracking*2*max(0,len(glyphs)-1))
                image=pg.Surface((max(1,width),max(1,f.get_height())),pg.SRCALPHA)
                x=0
                for glyph in glyphs:
                    image.blit(glyph,(int(x),0));x+=glyph.get_width()+tracking*2
            else:
                image=f.render(value,True,color)
            if image.get_width()==0:
                image=pg.Surface((1,max(1,image.get_height())),pg.SRCALPHA)
            image=pg.transform.smoothscale(image,(max(1,round(image.get_width()/2)),max(1,round(image.get_height()/2))))
            if len(self.text_images)>=384:self.text_images.clear()
            self.text_images[key]=image
        image=self.text_images[key]
        rect=image.get_rect(center=xy) if center else image.get_rect(topleft=xy)
        target.blit(image,rect)
        return rect

    def frame(self, rect, fill=(14,24,34), line=(47,66,79), accent=None, surface=None):
        target=surface or self.canvas
        r=pg.Rect(rect)
        cut=min(18,max(4,r.height//5))
        points=[(r.left+cut,r.top),(r.right-cut,r.top),(r.right,r.top+cut),
                (r.right,r.bottom-cut),(r.right-cut,r.bottom),(r.left+cut,r.bottom),
                (r.left,r.bottom-cut),(r.left,r.top+cut)]
        pg.draw.polygon(target,fill,points)
        pg.draw.lines(target,line,True,points,1)
        # Matching 45-degree bevels at all corners form one visual language.
        edge=accent or tuple(min(255,c+26) for c in line)
        pg.draw.line(target,edge,points[0],points[-1],2)
        pg.draw.line(target,edge,points[3],points[4],2)
        if accent:
            pg.draw.line(target,accent,points[0],(r.left+cut+min(48,r.width//3),r.top),2)
            pg.draw.line(target,tuple(c//2 for c in accent),(r.right-cut-32,r.bottom),points[4],2)
        return r

    def mark(self, pos, color=MINT, scale=1, surface=None):
        target=surface or self.canvas
        x,y=pos
        for i in range(3):
            pg.draw.polygon(target,color,[(x+i*9*scale,y+18*scale),(x+(i*9+8)*scale,y),
                            (x+(i*9+13)*scale,y),(x+(i*9+5)*scale,y+18*scale)])

    def keycap(self, label, pos, width=42):
        self.frame((pos[0],pos[1],width,23),(24,37,47),(66,86,97))
        self.text(label,(pos[0]+width/2,pos[1]+11),11,WHITE,True,True)

    def meter(self, rect, progress, color=MINT):
        r=pg.Rect(rect)
        pg.draw.rect(self.canvas,(31,45,56),r)
        width=int(r.width*max(0,min(1,progress)))
        if width:
            pg.draw.rect(self.canvas,color,(r.x,r.y,width,r.height))
            pg.draw.rect(self.canvas,WHITE,(r.x+width-2,r.y,2,r.height))

    def hero(self, index):
        if index not in self.hero_art:
            image=pg.Surface((1050,870),pg.SRCALPHA)
            self.ship(image,V(525,435),unit((1,-.7)),CHARACTERS[index][2],216,index)
            self.hero_art[index]=pg.transform.smoothscale(image,(350,290))
        return self.hero_art[index]

    def glow(self, surface, pos, color, radius=18):
        key = (tuple(color), radius)
        if key not in self.glows:
            s = pg.Surface((radius * 4, radius * 4))
            for r in range(radius * 2, 0, -2):
                strength = .14 * (1 - r / (radius * 2)) ** 2
                pg.draw.circle(s, tuple(int(c * strength) for c in color), (radius * 2, radius * 2), r)
            self.glows[key] = s
        surface.blit(self.glows[key], (int(pos[0] - radius * 2), int(pos[1] - radius * 2)), special_flags=pg.BLEND_RGB_ADD)

    def make_background(self):
        s = pg.Surface((W, H))
        s.fill((6,12,18))
        pg.draw.rect(s,(8,17,24),ARENA)
        # Floor seams are deliberately dimmer than every projectile and hazard.
        for y in range(ARENA.top+8,ARENA.bottom,80):
            for x in range(ARENA.left+8,ARENA.right,100):
                r=pg.Rect(x,y,min(94,ARENA.right-x-4),min(74,ARENA.bottom-y-4))
                pg.draw.rect(s,(12,23,30),r,1)
                pg.draw.line(s,(19,33,40),(x+6,y+5),(x+18,y+5),1)
        for radius in (160,260,360):
            pg.draw.circle(s,(16,29,37),ARENA.center,radius,1)
        pg.draw.line(s,(18,31,38),(640,ARENA.top+20),(640,ARENA.bottom-20))
        pg.draw.line(s,(18,31,38),(ARENA.left+20,423),(ARENA.right-20,423))
        for x in range(78,1210,100):
            pg.draw.rect(s,(24,42,51),(x,ARENA.top-6,42,4))
            pg.draw.rect(s,(24,42,51),(x,ARENA.bottom+3,42,4))
        for y in range(162,708,68):
            pg.draw.line(s,(42,66,75),(40,y),(48,y),2)
            pg.draw.line(s,(42,66,75),(1232,y),(1240,y),2)
        pg.draw.rect(s,(44,76,84),ARENA,1)
        for x,y,sx,sy in [(54,128,1,1),(1226,128,-1,1),(54,718,1,-1),(1226,718,-1,-1)]:
            pg.draw.line(s,MINT,(x+sx*12,y),(x+sx*60,y),3)
            pg.draw.line(s,MINT,(x,y+sy*12),(x,y+sy*60),3)
        self.text('SECTOR / PB-01',(75,139),10,(43,63,73),surface=s)
        self.text('COMBAT ZONE',(1103,694),10,(43,63,73),surface=s)
        return s

    def make_menu_background(self):
        # Code-native orbital display: the same neon language as the arena,
        # with no image downloads or photorealistic/mascot artwork.
        s=pg.Surface((W,H))
        for y in range(H):
            depth=1-abs(y-340)/H
            pg.draw.line(s,(6+int(depth*3),11+int(depth*5),23+int(depth*10)),(0,y),(W,y))
        rng=random.Random(401)
        for _ in range(160):
            x=rng.randrange(530,W);y=rng.randrange(14,670)
            value=rng.randrange(30,95)
            pg.draw.circle(s,(value//2,value*3//4,value),(x,y),1)
        planet=V(1000,268)
        self.glow(s,planet,BLUE,165)
        pg.draw.circle(s,(12,29,47),planet,194)
        pg.draw.circle(s,(43,93,115),planet,194,2)
        for radius in (130,163,205,225,254):
            pg.draw.arc(s,(22,55,78),pg.Rect(planet.x-radius,planet.y-radius,radius*2,radius*2),-.7,2.4,1)
        for offset in (-95,-45,5,55,105):
            chord=math.sqrt(max(0,194**2-offset**2))
            pg.draw.line(s,(18,43,63),(planet.x-chord,planet.y+offset),(planet.x+chord,planet.y+offset),1)
        pg.draw.arc(s,BLUE,(806,74,388,388),4.3,5.5,2)
        pg.draw.ellipse(s,(44,79,105),(690,173,590,196),1)
        for i in range(4):
            pg.draw.line(s,(45,102,126),(1155+i*9,650-i*8),(1210+i*9,609-i*8),2)
        for x in range(-300,1600,130):
            pg.draw.line(s,(17,37,54),(640+(x-640)*.32,570),(x,H),1)
        for y in (588,611,641,678,724,780):
            pg.draw.line(s,(19,43,60),(525,y),(W,y),1)
        pg.draw.line(s,(41,113,123),(596,780),(1221,780),2)
        shade=pg.Surface((W,H),pg.SRCALPHA)
        for x in range(710):
            alpha=int(180*(1-x/710))
            pg.draw.line(shade,(6,12,24,alpha),(x,0),(x,H))
        s.blit(shade,(0,0))
        pg.draw.line(s,(50,69,79),(84,126),(1206,126))
        pg.draw.line(s,(50,69,79),(84,732),(1206,732))
        return s

    def button(self, key, label, rect, primary=False):
        r=pg.Rect(rect)
        self.buttons[key]=r
        hover=r.collidepoint(self.mouse)
        fill=(145,255,225) if primary and hover else MINT if primary else (34,51,63) if hover else (17,29,40)
        self.frame(r,fill,WHITE if hover else MINT if primary else (63,83,96))
        size=16 if r.height>34 else 13
        self.text(label,(r.centerx,r.centery-1),size,(7,33,32) if primary else WHITE,primary,True)
        if primary and r.width>250:
            x=r.right-23;y=r.centery
            pg.draw.lines(self.canvas,(7,33,32),False,[(x-5,y-5),(x,y),(x-5,y+5)],2)

    def clear_input(self):
        self.keys.clear()
        self.mouse_buttons.clear()
        self.pending_dash = self.pending_parry = False

    def start(self, practice=False):
        problem = name_problem(self.name)
        if problem and not practice:
            self.state = 'menu'
            self.name_error = problem
            self.name_active = True
            pg.key.start_text_input()
            self.clear_input()
            return
        if not practice:
            self.name = safe_name(self.name) if self.name.strip() else ''
        self.name_error = ''
        self.world = World(opening=not practice, festival=self.festival, character=self.character,practice=practice)
        self.audio.stop()
        self.particles, self.rings, self.labels, self.trails = [], [], [], []
        self.shake = self.hitstop = self.toast_left = 0
        self.stage_banner, self.flash, self.zoom, self.slomo = 0, 0, 0, 0
        self.damage_tint = self.desaturation = 0.0
        self.saved_run = False
        self.clear_input()
        self.name_active = False
        self.composition = ''
        pg.key.stop_text_input()
        self.state, self.count, self.last_count, self.acc = 'countdown', 1.0, -1, 0

    def pause(self):
        if self.state in ('play', 'countdown'):
            self.state = 'pause'
            self.audio.stop()
            self.clear_input()

    def resume(self):
        if self.state == 'pause':
            self.state, self.count, self.last_count, self.acc = 'countdown', 3.0, -1, 0
            self.clear_input()

    def announce(self, title, detail='', seconds=1.4):
        self.toast, self.toast_left = (title, detail), seconds

    def particle(self, pos, color, amount=15, speed=190):
        if self.reduced:
            amount = min(amount, 4)
        for _ in range(amount):
            angle = self.rng.random() * math.tau
            v = V(math.cos(angle), math.sin(angle)) * self.rng.uniform(30, speed)
            self.particles.append(dict(pos=V(pos), vel=v, life=self.rng.uniform(.2, .6), color=color, size=self.rng.randint(2, 4)))
        self.particles = self.particles[-500:]

    def impact_burst(self, pos, color, radius, strength=.2, flash=0):
        """Presentation only: bounded shockwaves, with no changes to combat timing."""
        if self.reduced:
            return
        self.shake = max(self.shake, strength)
        self.zoom = max(self.zoom, strength * .8)
        self.flash = max(self.flash, flash)
        for scale, life in ((1, .32), (.72, .48)):
            self.rings.append(dict(pos=V(pos), life=life, max=life,
                                   radius=radius*scale, color=color, spokes=True))
        self.rings = self.rings[-80:]

    def effects(self):
        reflection_sound = False
        laser_sound = False
        pulse_sound = False
        for e in self.world.drain():
            kind = e['kind']
            pos = e.get('pos', self.world.pos)
            if kind in ('dash', 'parry', 'impact', 'kill', 'hurt', 'heal'):
                self.audio.play(kind)
            if kind == 'shot':
                self.audio.play(('shot','shot_twin','shot_cannon','shot_spread')[e.get('weapon',0)])
                self.particle(pos, MINT, 3, 65)
            elif kind == 'dash':
                self.particle(pos, BLUE, 40, 380)
                self.rings.append(dict(pos=V(pos), life=.28, max=.28, radius=66, color=BLUE))
                self.zoom = max(self.zoom, .18)
                self.impact_burst(pos, BLUE, 100, .18)
            elif kind == 'parry':
                self.rings.append(dict(pos=V(pos), life=.24, max=.24, radius=105, color=MINT))
            elif kind == 'reflect':
                self.particle(pos, GOLD, 32, 360)
                self.hitstop = max(self.hitstop, .025)
                self.slomo = max(self.slomo, .14)
                self.rings.append(dict(pos=V(pos), life=.35, max=.35, radius=105, color=GOLD))
                self.zoom = max(self.zoom, .27)
                reflection_sound = True
            elif kind == 'impact':
                self.particle(pos, GOLD if e['reflected'] else BLUE, 9, 290)
            elif kind == 'kill':
                self.particle(pos, PINK, 160 if e['boss'] else 48, 560)
                self.impact_burst(pos, GOLD if e['boss'] else PINK,
                                  360 if e['boss'] else 82, .5 if e['boss'] else .32)
                self.rings.append(dict(pos=V(pos), life=.4, max=.4, radius=160 if e['boss'] else 52, color=GOLD if e['boss'] else PINK))
                self.labels.append(dict(pos=V(pos), text='+' + str(e['score']), life=.8))
                self.hitstop = max(self.hitstop, .1 if e['boss'] else .025)
                self.shake = max(self.shake, .4 if e['boss'] else .08)
                if e['boss']:
                    self.audio.stop()
                    self.audio.play('boss_down')
                    self.slomo = .6
                    self.flash = .28
                    for i in range(3):
                        self.rings.append(dict(pos=V(pos), life=.6+i*.17, max=.6+i*.17, radius=250+i*110, color=GOLD))
                    detail = ('최종 보스 격파! 행사 도전 완료!' if self.festival else '최종 보스 격파! 다음 라운드 시작!') if e.get('stage_boss',FINAL_STAGE)==FINAL_STAGE else '스테이지 보스 격파! 체력 회복 · 레이저 코어 드롭'
                    self.announce('BOSS DOWN',detail,2)
            elif kind == 'hurt':
                self.particle(pos, PINK, 35)
                self.shake = max(self.shake, .85)
                self.damage_tint = .6
                self.announce('HIT', '방향키 + Shift로 탈출하세요', .7)
            elif kind == 'heal':
                self.announce('REPAIR +1', '15기 격파 · 체력 회복')
                self.particle(pos, MINT, 28, 180)
                self.rings.append(dict(pos=V(pos), life=.55, max=.55, radius=110, color=MINT))
            elif kind == 'phase':
                self.stage_banner = 2.5
                self.audio.play('stage')
                self.impact_burst(V(640, 423), STAGES[e['phase']-1][2], 480, .24)
                self.rings.append(dict(pos=V(640, 423), life=.9, max=.9, radius=680, color=STAGES[e['phase']-1][2]))
            elif kind == 'round':
                self.stage_banner = 2.5
                self.audio.play('stage')
                self.impact_burst(pos, GOLD, 420, .32, .12)
                self.announce('ROUND %02d' % e['round'], '누적 점수 유지 · 계속 살아남으세요!', 2.5)
            elif kind == 'first_blood':
                self.announce('NICE SHOT!', '첫 격파 성공! 무기 강화가 시작됩니다', 1.8)
                self.audio.play('overdrive')
                self.rings.append(dict(pos=V(pos), life=.7, max=.7, radius=240, color=MINT))
                self.particle(pos, MINT, 55, 390)
            elif kind == 'milestone':
                self.announce('%s POINTS!' % format(e['score'], ','), '목표 달성! 다음 기록도 넘어보세요', 1.3)
                self.audio.play('heal')
                self.particle(pos, GOLD, 45, 350)
                self.impact_burst(pos, GOLD, 180, .16)
            elif kind == 'overdrive':
                self.announce('OVERDRIVE!', '6초간 무기 강화 · 격파 점수 ×2 · 스킬 즉시 충전', 2)
                self.audio.play('overdrive')
                self.rings.append(dict(pos=V(pos), life=.7, max=.7, radius=320, color=MINT))
                self.particle(pos, MINT, 65, 420)
                self.zoom = .35
                self.impact_burst(pos, MINT, 360, .3, .12)
            elif kind == 'bonus':
                self.announce('BONUS DRONE', '초록 드론 격파 → 무기 강화 + 레이저 코어 드롭!', 1.8)
            elif kind == 'supply':
                self.particle(pos,BLUE,25,180)
                self.audio.play('supply')
                self.announce('CORE SUPPLY', '파란 보급 드론을 잡고 레이저 코어를 가져오세요!', 1.2)
            elif kind == 'supply_down':
                self.particle(pos,BLUE,35,280)
                self.labels.append(dict(pos=V(pos),text='LASER CORE',life=1))
            elif kind == 'near_miss':
                self.audio.play('near_miss')
                self.particle(pos,BLUE,12,180)
                self.rings.append(dict(pos=V(pos),life=.3,max=.3,radius=55,color=BLUE))
                self.labels.append(dict(pos=V(pos)+V(0,-35),text='NEAR MISS +75',life=.8))
            elif kind == 'wall_hit':
                self.particle(pos,BLUE,4,80)
            elif kind == 'gimmick_warning':
                if not pulse_sound:
                    self.audio.play('pulse_charge')
                    pulse_sound=True
            elif kind == 'gimmick_fire':
                if not pulse_sound:
                    self.audio.play('pulse_blast')
                    pulse_sound=True
                color=BLUE if self.world.phase==4 else PINK
                self.particle(pos,color,32,260)
                self.impact_burst(pos,color,130,.22,.07)
                self.rings.append(dict(pos=V(pos),life=.5,max=.5,radius=130,color=color))
            elif kind == 'boss_transform':
                self.audio.play('transform')
                self.impact_burst(pos,PINK,380,.45,.18)
                self.particle(pos,PINK,85,450)
                self.rings.append(dict(pos=V(pos),life=.9,max=.9,radius=300,color=PINK))
                detail={'ram':'가속 돌진 · 돌진 끝에 원형 탄막!', 'prism':'확산탄 · 이중 대각선 레이저!',
                        'specter':'강화 뼈 탄막 · 연속 순간이동!', 'vortex':'고밀도 회전 탄막!',
                        'overlord':'9발 확산탄 · 더 잦은 교차 포격!'}.get(e['variant'],'강화 탄막 발동!')
                self.announce('PHASE II / '+BOSS_NAMES.get(e['variant'],'CORE').split(' / ')[0],detail,1.7)
            elif kind == 'practice_lesson':
                self.audio.play('heal')
                self.rings.append(dict(pos=V(pos),life=.4,max=.4,radius=95,color=MINT))
            elif kind == 'practice_refill':
                self.audio.play('supply')
            elif kind == 'cell':
                self.audio.play('heal')
                self.announce('BREAKER CELL +1', '좌클릭 %.2f초 충전 → 지면 분쇄 레이저! 최대 2발' % self.world.charge_duration, 2)
            elif kind == 'pickup':
                color = MINT if e['pickup']=='repair' else BLUE if e['pickup']=='shield' else GOLD
                title, detail = {'repair': ('REPAIR +1', '체력 1칸 회복'),
                                 'shield': ('SHIELD READY', '다음 피해 1회 차단'),
                                 'nova': ('SHOCKWAVE!', '주변 적에게 12 피해 · 주변 탄환 소거')}[e['pickup']]
                self.audio.play('reflect' if e['pickup']=='nova' else 'heal')
                self.particle(pos, color, 45, 340)
                self.impact_burst(pos, color, 320 if e['pickup']=='nova' else 140, .3 if e['pickup']=='nova' else .12)
                self.rings.append(dict(pos=V(pos), life=.6,max=.6,radius=320 if e['pickup']=='nova' else 140,color=color))
                self.announce(title, '+300점 · 이미 가득 찼습니다' if e['bonus'] else detail, 1.5)
            elif kind == 'shield_break':
                self.audio.play('parry')
                self.particle(pos, BLUE, 40, 300)
                self.impact_burst(pos, BLUE, 130, .18)
                self.announce('BLOCK!', '보호막이 피해를 막았습니다', .8)
            elif kind == 'ability':
                ability = e['ability']
                color = CHARACTERS[self.character][2]
                title = {'pulse':'PULSE COUNTER', 'blade':'DASH BLADE', 'armor':'ARMOR REBUILT', 'nova':'NOVA BURST'}[ability]
                radius = {'pulse':150, 'blade':65, 'armor':95, 'nova':180}[ability]
                self.particle(pos,color,35,350)
                self.rings.append(dict(pos=V(pos),life=.45,max=.45,radius=radius,color=color))
                self.impact_burst(pos,color,radius,.24)
                self.audio.play('heal' if ability=='armor' else 'reflect')
                self.announce(title, ABILITIES[self.character], .9)
            elif kind == 'beam_charge':
                self.audio.play('beam_charge_nova' if self.world.character == 3 else 'beam_charge')
            elif kind == 'beam_cancel':
                if self.audio.ready:
                    pg.mixer.Channel(6).stop()
            elif kind == 'beam_fire':
                if self.audio.ready:
                    pg.mixer.Channel(6).stop()
                self.audio.play('beam_fire')
                self.impact_burst(pos, BLUE, 420, .55, .2)
                self.particle(pos, GOLD, 100, 500)
                self.announce('GROUND BREAKER', '관통 · 탄환 소거 · 1.4초 집중 포격', 1.2)
            elif kind == 'laser_warning':
                self.audio.play('laser_charge')
            elif kind == 'laser_fire':
                if not laser_sound:
                    self.audio.play('laser')
                    laser_sound = True
                self.shake = max(self.shake, .32)
                self.flash = max(self.flash, .16)
                self.zoom = max(self.zoom, .16)
                if not self.reduced:
                    ends = laser_ends(e['axis'],e['coord'])
                    for end in ends:
                        self.particle(end, PINK, 22, 300)
                        self.rings.append(dict(pos=end, life=.35, max=.35, radius=85, color=PINK))
            elif kind == 'rage':
                self.audio.play('rage')
                self.impact_burst(pos, PINK, 340, .38, .16)
                self.particle(pos, PINK, 80, 440)
                self.announce('CORE / ENRAGED', '회전 탄막 발동 · 반사로 코어를 무너뜨리세요', 2)
                self.rings.append(dict(pos=V(pos), life=.75, max=.75, radius=220, color=PINK))
            elif kind == 'blink':
                self.particle(pos,BLUE,40,320)
                self.rings.append(dict(pos=V(pos),life=.45,max=.45,radius=100,color=BLUE))
            elif kind == 'boss':
                variant=e.get('variant','core')
                detail={'ram':'돌진 전 경고선을 보고 옆으로 이동!','prism':'레이저 충전 중 집중 공격!','specter':'순간이동 예고 · 탄막 틈으로 이동!',
                        'vortex':'회전 탄막 사이로 이동 · 반사로 반격!', 'overlord':'최종전 · 교차 포격과 연속 탄막!', 'core':'반사탄으로 코어를 공격하세요'}[variant]
                self.announce(BOSS_NAMES[variant],detail,2.3)
                self.audio.play('rage')
                self.impact_burst(pos, GOLD, 380, .38, .14)
                self.particle(pos, GOLD, 70, 380)
            elif kind == 'finish':
                self.finish()
        if reflection_sound:
            self.impact_burst(self.world.pos, GOLD, 160, .28)
            self.audio.play('reflect')
            self.announce('REFLECT!', '탄환을 적에게 되돌렸습니다 · +25', .65)
        self.rings = self.rings[-80:]
        self.labels = self.labels[-60:]

    def finish(self):
        if self.saved_run:
            return
        self.saved_run = True
        self.clear_input()
        if self.world.practice:
            self.state='practice_result'
            self.audio.stop();self.audio.play('finish')
            return
        self.state = 'result'
        name = safe_name(self.name)
        self.rank = 1 + sum(r['score'] > self.world.score for r in self.records)
        self.records.append(dict(name=name, score=self.world.score, kills=self.world.kills,
                                 reflected=self.world.reflected, near_misses=self.world.near_misses,
                                 time=round(self.world.time, 1), stage_round=self.world.round))
        self.records = sorted(self.records, key=lambda r: -r['score'])[:100]
        self.persist()
        self.audio.stop()
        self.audio.play('finish')

    def activate(self, key):
        if key.startswith('character_'):
            choice = key.removeprefix('character_')
            if self.state == 'menu' and choice.isdigit() and 0 <= int(choice) < len(CHARACTERS):
                self.character = int(choice)
                self.audio.play('parry')
                self.persist()
            return
        if key in ('start', 'again'):
            self.start()
        elif key in ('practice','practice_again'):
            self.start(practice=True)
        elif key == 'resume':
            self.resume()
        elif key in ('menu', 'next'):
            self.audio.stop()
            self.state = 'menu'
            self.clear_input()
            self.toast_left = 0
            if key == 'next':
                self.name = ''
            self.name_error = ''
        elif key == 'guide':
            self.state = 'guide'
        elif key == 'back':
            self.state = 'menu'
        elif key == 'exit':
            self.running = False
        elif key == 'sound':
            self.audio.enabled = not self.audio.enabled
            if not self.audio.enabled and self.audio.ready:
                pg.mixer.stop()
            self.persist()
        elif key == 'motion':
            self.reduced = not self.reduced
            self.persist()
        elif key in ('motion_intense', 'motion_calm'):
            self.reduced = key == 'motion_calm'
            if self.reduced:
                self.shake = self.flash = self.zoom = 0
                self.trails.clear()
                self.particles = self.particles[-20:]
            self.persist()

    def handle(self, event):
        if event.type == pg.QUIT:
            self.running = False
        elif event.type == pg.WINDOWFOCUSLOST:
            self.pause()
            self.clear_input()
        elif event.type == pg.VIDEORESIZE and not self.fullscreen:
            self.last_window = (max(800, event.w), max(500, event.h))
            self.screen = pg.display.set_mode(self.last_window, pg.RESIZABLE)
        elif event.type in (pg.MOUSEMOTION, pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP):
            self.mouse = (V(event.pos) - self.offset) / max(.01, self.scale)
            if event.type == pg.MOUSEBUTTONDOWN:
                if self.state == 'play':
                    if event.button in (1, 3):
                        self.mouse_buttons.add(event.button)
                    if event.button == 3:
                        self.pending_parry = True
                elif event.button == 1:
                    if self.state == 'menu':
                        self.name_active = pg.Rect(84, 502, 378, 47).collidepoint(self.mouse)
                        if self.name_active:
                            pg.key.start_text_input()
                            pg.key.set_text_input_rect(pg.Rect(int(84 * self.scale + self.offset.x), int(550 * self.scale + self.offset.y), 300, 35))
                        else:
                            pg.key.stop_text_input()
                    for key, rect in list(self.buttons.items()):
                        if rect.collidepoint(self.mouse):
                            self.activate(key)
                            break
            elif event.type == pg.MOUSEBUTTONUP:
                self.mouse_buttons.discard(event.button)
        elif event.type == pg.TEXTINPUT and self.state == 'menu' and self.name_active:
            self.name = (self.name + ''.join(c for c in event.text if c.isprintable()))[:12]
            self.composition = ''
            self.name_error = name_problem(self.name) or ''
        elif event.type == pg.TEXTEDITING and self.name_active:
            self.composition = event.text
        elif event.type == pg.KEYUP:
            self.keys.discard(event.key)
        elif event.type == pg.KEYDOWN:
            repeat = event.key in self.keys
            self.keys.add(event.key)
            if event.key == pg.K_F11:
                self.pause()
                self.fullscreen = not self.fullscreen
                self.screen = pg.display.set_mode((0, 0), pg.FULLSCREEN) if self.fullscreen else pg.display.set_mode(self.last_window, pg.RESIZABLE)
                return
            if self.state == 'menu' and self.name_active:
                if event.key == pg.K_BACKSPACE and not self.composition:
                    self.name = self.name[:-1]
                    self.name_error = name_problem(self.name) or ''
                if event.key == pg.K_RETURN and not self.composition:
                    self.start()
                return
            if event.key == pg.K_ESCAPE:
                if self.state in ('play', 'countdown'):
                    self.pause()
                elif self.state == 'pause':
                    self.resume()
                elif self.state in ('guide', 'result','practice_result'):
                    self.activate('menu')
            elif event.key == pg.K_RETURN and not repeat:
                if self.state in ('menu', 'result','practice_result'):
                    self.start()
                elif self.state == 'pause':
                    self.resume()
            elif self.state == 'play' and not repeat:
                if event.key in (pg.K_LSHIFT, pg.K_RSHIFT):
                    self.pending_dash = True
                elif event.key in (pg.K_e, pg.K_RCTRL):
                    self.pending_parry = True
            elif event.key == pg.K_h and self.state == 'menu':
                self.state = 'guide'
            elif event.key == pg.K_t and self.state == 'menu':
                self.start(practice=True)

    def update(self, dt):
        if not math.isfinite(dt) or dt < 0:
            return
        if dt > .3:
            self.pause()
        dt = min(dt, .05)
        if self.state in ('pause', 'guide'):
            return
        self.visual_time += dt
        self.stage_banner = max(0, self.stage_banner - (dt if self.state != 'countdown' else 0))
        self.flash = max(0, self.flash - dt)
        self.damage_tint = max(0, self.damage_tint-dt)
        target_gray = .92 if self.world.hp <= 1 else .65 if self.world.hp == 2 else 0
        self.desaturation += (target_gray-self.desaturation)*(1-math.exp(-dt*7))
        self.zoom = max(0, self.zoom - dt)
        slowed = self.slomo > 0
        self.slomo = max(0, self.slomo - dt)
        self.shake = max(0, self.shake - dt)
        self.toast_left = max(0, self.toast_left - dt)
        for p in self.particles:
            p['pos'] += p['vel'] * dt
            p['vel'] *= math.exp(-dt * 3)
            p['life'] -= dt
        self.particles = [p for p in self.particles if p['life'] > 0]
        for group in (self.rings, self.labels, self.trails):
            for p in group:
                p['life'] -= dt
        for p in self.labels:
            p['pos'].y -= dt * 35
        self.rings = [p for p in self.rings if p['life'] > 0]
        self.labels = [p for p in self.labels if p['life'] > 0]
        self.trails = [p for p in self.trails if p['life'] > 0]
        if self.state == 'countdown':
            self.count -= dt
            if math.ceil(self.count) != self.last_count and self.count > 0:
                self.last_count = math.ceil(self.count)
                self.audio.play('count')
            if self.count <= 0:
                self.state = 'play'
                self.audio.play('start')
                self.clear_input()
                self.acc = 0
        elif self.state == 'play':
            if self.hitstop > 0:
                self.hitstop = max(0, self.hitstop - dt)
                return
            movement = V(int(pg.K_RIGHT in self.keys) - int(pg.K_LEFT in self.keys),
                         int(pg.K_DOWN in self.keys) - int(pg.K_UP in self.keys))
            self.acc += dt * (.48 if slowed else 1)
            while self.acc >= STEP and self.state == 'play':
                self.world.step(STEP, movement, self.aim_point() - self.world.pos,
                                1 in self.mouse_buttons or pg.K_SPACE in self.keys,
                                self.pending_dash, self.pending_parry)
                self.pending_dash = self.pending_parry = False
                self.acc -= STEP
                self.effects()
            if self.world.dash_time > 0 and not self.reduced:
                self.trails.append(dict(pos=self.world.pos.copy(), aim=self.world.aim.copy(), life=.18))
            beat = int(self.world.time / .25)
            if beat != self.music_beat:
                self.music_beat = beat
                if beat % 2 == 0:
                    self.audio.play('music' + str([0, 4, 2, 6, 1, 5, 3, 7][(beat // 2) % 8]))

    def camera_offset(self):
        if self.reduced:
            return V()
        active = any(h['warn'] <= h['age'] < h['warn']+h['active'] for h in self.world.hazards)
        strength = max(self.shake, .95 if active else 0, 1.1 if self.world.beam_left > 0 else 0)
        return V(math.sin(self.visual_time*91)*strength*18, math.cos(self.visual_time*81)*strength*12)

    def aim_point(self):
        if self.reduced:
            return self.mouse.copy()
        offset = self.camera_offset()
        factor = 1+self.zoom*.045
        sx,sy=int(W*factor)/W,int(H*factor)/H
        point=self.mouse-offset-V(W/2,H/2)
        return V(point.x/sx,point.y/sy)+V(W/2,H/2)

    def ship(self, surface, pos, aim, color, size=19, character=None):
        index=self.character if character is None else character
        side=V(-aim.y,aim.x)
        def point(x,y): return pos+aim*x*size+side*y*size
        def poly(coords,fill,outline=None):
            pts=[point(x,y) for x,y in coords]
            pg.draw.polygon(surface,fill,pts)
            if outline: pg.draw.lines(surface,outline,True,pts,max(1,int(size*.018)))
        def line(a,b,fill,width=.025):
            pg.draw.line(surface,fill,point(*a),point(*b),max(1,int(size*width)))
        metal=tuple(38+int(c*.23) for c in color);light=(167,190,199);dark=(14,24,37)
        armor=tuple(int(c*.27) for c in color)
        silhouettes=[[(1.55,0),(.3,.3),(-.82,.92),(-1.08,.82),(-.68,.1),(-1.06,0),(-.68,-.1),(-1.08,-.82),(-.82,-.92),(.3,-.3)],
                     [(1.3,0),(.2,.27),(-.92,1.22),(-1.28,1.02),(-.82,.25),(-1.18,0),(-.82,-.25),(-1.28,-1.02),(-.92,-1.22),(.2,-.27)],
                     [(1.42,.22),(.6,.24),(.15,.78),(-.95,.82),(-1.12,.48),(-.85,0),(-1.12,-.48),(-.95,-.82),(.15,-.78),(.6,-.24),(1.42,-.22)],
                     [(1.45,0),(.48,.22),(.05,1.04),(-.28,.82),(-.4,.35),(-1.12,.14),(-1.12,-.14),(-.4,-.35),(-.28,-.82),(.05,-1.04),(.48,-.22)]]
        # The solid central hull stays readable at the actual 19-pixel play size.
        shadow=[point(x,y)+V(3,5)*(size/35) for x,y in silhouettes[index]]
        pg.draw.polygon(surface,(3,9,15),shadow)
        jet=.8 if self.reduced else .8+.12*math.sin(self.visual_time*22)
        for sign in (-1,1):
            offset=.5 if index==2 else .38
            poly([(-.78,offset*sign-.1),(-.78,offset*sign+.1),(-1.1-jet*.35,offset*sign)],armor)
            line((-.83,offset*sign),(-1.15,offset*sign),color,.09)
            line((-.82,offset*sign),(-1.0,offset*sign),WHITE,.035)
        poly(silhouettes[index],metal,light)
        for sign in (-1,1):
            if index==0:
                poly([(.49,.13*sign),(-.79,.75*sign),(-.88,.61*sign),(-.43,.16*sign)],dark)
                poly([(.05,.2*sign),(-.76,.69*sign),(-.43,.4*sign)],armor)
                line((-.76,.76*sign),(-.44,.57*sign),color,.045)
                poly([(-.7,.34*sign),(-.35,.29*sign),(-.35,.45*sign),(-.7,.5*sign)],(76,92,103),dark)
            elif index==1:
                poly([(.2,.2*sign),(-1.08,1.05*sign),(-.92,.6*sign),(-.42,.25*sign)],dark,armor)
                poly([(-.44,.48*sign),(-.97,1.09*sign),(-.8,.75*sign)],(49,56,83))
                line((-.87,1.05*sign),(-.67,.87*sign),color,.045)
                line((-.22,.3*sign),(.78,.15*sign),color,.04)
                poly([(.4,.19*sign),(-.02,.22*sign),(-.1,.34*sign),(.56,.28*sign)],light,dark)
            elif index==2:
                poly([(.02,.36*sign),(-.83,.36*sign),(-.93,.65*sign),(.08,.65*sign)],(98,104,104),dark)
                for x in (-.64,-.36,-.08): line((x,.4*sign),(x,.6*sign),dark,.045)
                poly([(1.34,.12*sign),(.28,.12*sign),(.16,.28*sign),(1.34,.28*sign)],dark,light)
                line((.91,.2*sign),(1.32,.2*sign),color,.06)
                line((-.87,.74*sign),(-.47,.74*sign),color,.05)
            else:
                poly([(.28,.17*sign),(.02,.91*sign),(-.14,.64*sign),(-.16,.2*sign)],(81,69,86),light)
                line((.01,.74*sign),(.11,.47*sign),color,.07)
                line((-.88,.14*sign),(-.48,.22*sign),color,.045)
        poly([(1.2,0),(.12,.18),(-.72,.13),(-.86,0),(-.72,-.13),(.12,-.18)],(100,118,129),dark)
        poly([(.48,0),(.05,.14),(-.38,.08),(-.43,-.08),(.05,-.14)],(9,36,49),light)
        poly([(.36,-.015),(.02,-.095),(-.26,-.04),(.03,.01)],(99,191,208))
        line((.85,0),(1.18,0),WHITE,.025)
        if index==3:
            pg.draw.circle(surface,color,point(-.48,0),max(2,int(size*.23)),max(1,int(size*.035)))
        if size>40:
            for sign in (-1,1):
                line((-.42,.52*sign),(-.31,.47*sign),(190,206,204),.015)
                pg.draw.circle(surface,color,point(-.8,.65*sign),max(1,int(size*.018)))

    def enemy_body(self, surface, enemy, color):
        pos=enemy['pos'];r=enemy['r'];kind=enemy['kind']
        variant=enemy.get('variant','core')
        rage=enemy.get('rage',False)
        rotation=0 if self.reduced else self.visual_time
        fill=WHITE if enemy['hit']>0 else (48,61,73)
        dark=(10,20,29);edge=(106,126,142)
        def poly(coords,base=fill,trim=edge):
            points=[pos+V(x,y) for x,y in coords]
            pg.draw.polygon(surface,base,points)
            pg.draw.lines(surface,trim,True,points,1)
        def core(at,radius,tint=color):
            pg.draw.circle(surface,dark,at,radius+4)
            pg.draw.circle(surface,tint,at,radius,2)
            pg.draw.circle(surface,WHITE,at,max(2,radius//3))
        if kind!='boss':
            aim=unit(enemy.get('aim',V(1,0)))
            side=aim.rotate(90)
            def p(coords,base=fill,trim=edge):
                points=[pos+aim*x*r+side*y*r for x,y in coords]
                pg.draw.polygon(surface,base,points)
                pg.draw.lines(surface,trim,True,points,1)
            if kind=='chaser':
                p([(1,0),(-.7,.82),(-.4,0),(-.7,-.82)])
                p([(.6,0),(-.58,.6),(-.28,0),(-.58,-.6)],dark,color)
                pg.draw.circle(surface,color,pos,3)
            elif kind=='shooter':
                p([(.76,.6),(-.6,.76),(-.76,-.6),(.6,-.76)])
                p([(.39,.34),(-.34,.39),(-.39,-.34),(.34,-.39)],dark,color)
                pg.draw.line(surface,color,pos+aim*r*.5,pos+aim*r,3)
                core(pos,4)
            elif kind=='bruiser':
                p([(.9,.35),(.25,.85),(-.8,.7),(-1,0),(-.8,-.7),(.25,-.85),(.9,-.35)])
                for sign in (-1,1):
                    p([(.3,.38*sign),(-.74,.42*sign),(-.67,.66*sign),(.08,.65*sign)],dark,color)
                core(pos,7)
            elif kind=='weaver':
                p([(1,0),(.16,.3),(-.1,.8),(-.77,.55),(-.4,0),(-.77,-.55),(-.1,-.8),(.16,-.3)])
                pg.draw.line(surface,color,pos-side*r*.6,pos+side*r*.6,2)
                core(pos,4)
            elif kind=='sniper':
                p([(1,.16),(.0,.22),(-.75,.67),(-.6,0),(-.75,-.67),(.0,-.22),(1,-.16)])
                pg.draw.line(surface,color,pos,pos+aim*r,3)
                core(pos-aim*r*.23,3)
            elif kind=='spinner':
                poly([(math.cos(i*math.pi/4)*r,math.sin(i*math.pi/4)*r) for i in range(8)])
                for i in range(4):
                    ray=V(1,0).rotate(i*90+rotation*45)
                    pg.draw.line(surface,color,pos+ray*r*.6,pos+ray*r,3)
                core(pos,5)
            else:
                p([(.78,.5),(0,.9),(-.78,.5),(-.78,-.5),(0,-.9),(.78,-.5)],(31,64,70),color)
                for sign in (-1,1):
                    pg.draw.circle(surface,edge,pos+side*sign*r*.84,4)
                core(pos,5)
        elif variant=='ram':
            # Industrial battering ram: twin armored shoulders and a front blade.
            poly([(42,-10),(42,10),(16,29),(-29,25),(-38,0),(-29,-25),(16,-29)])
            poly([(34,0),(14,17),(-22,13),(-27,0),(-22,-13),(14,-17)],dark,MINT)
            for sign in (-1,1):
                poly([(-24,sign*17),(10,sign*20),(17,sign*29),(-24,sign*29)],(67,83,88))
                pg.draw.line(surface,MINT,pos+V(-18,sign*23),pos+V(5,sign*24),3)
                if rage:
                    poly([(-28,sign*27),(3,sign*47),(36,sign*35),(17,sign*22)],fill,PINK)
                    pg.draw.line(surface,PINK,pos+V(-7,sign*35),pos+V(18,sign*31),3)
            pg.draw.lines(surface,WHITE,False,[pos+V(19,-15),pos+V(31,0),pos+V(19,15)],3)
            core(pos-V(3,0),8,MINT if not rage else PINK)
        elif variant=='prism':
            tint=(190,156,255)
            poly([(0,-41),(36,0),(0,41),(-36,0)],fill,tint)
            for sign in (-1,1):
                poly([(0,sign*31),(27,0),(0,sign*12),(-27,0)],(56,43,73),edge)
                pg.draw.line(surface,tint,pos+V(sign*24,0),pos+V(sign*44,0),3)
                poly([(sign*43,-8),(sign*53,-8),(sign*59,0),(sign*53,8),(sign*43,8)],dark,tint)
                if rage:
                    poly([(sign*53,-10),(sign*74,-14),(sign*80,0),(sign*74,14),(sign*53,10)],fill,PINK)
                    core(pos+V(0,sign*47),5,PINK)
            core(pos,12,tint)
            pg.draw.lines(surface,WHITE,True,[pos+V(0,-7),pos+V(7,0),pos+V(0,7),pos+V(-7,0)],1)
        elif variant=='specter':
            tint=PINK if rage else BLUE
            pg.draw.circle(surface,dark,pos,34)
            pg.draw.circle(surface,edge,pos,32,1)
            for i in range(6 if rage else 4):
                ray=V(1,0).rotate(i*(60 if rage else 90)+rotation*25)
                side=ray.rotate(90)
                plate=[pos+ray*24-side*10,pos+ray*38-side*15,pos+ray*49,
                       pos+ray*38+side*15,pos+ray*24+side*10]
                pg.draw.polygon(surface,fill,plate);pg.draw.lines(surface,edge,True,plate,1)
                pg.draw.line(surface,tint,pos+ray*34-side*6,pos+ray*34+side*6,3)
            core(pos,15,tint)
            if enemy.get('teleport') is not None:
                target=enemy['teleport'];pg.draw.circle(surface,BLUE,target,50,2)
                for ray in (V(1,0),V(0,1)):
                    pg.draw.line(surface,BLUE,target-ray*14,target+ray*14,2)
                self.text('BLINK',(target.x,target.y-65),11,BLUE,True,True,surface)
        else:
            final=variant=='overlord'
            tint=PINK if final else BLUE if variant=='vortex' else GOLD
            count=(8 if final else 6) if rage else (6 if final else 3)
            pg.draw.circle(surface,dark,pos,40)
            pg.draw.circle(surface,edge,pos,36,1)
            for i in range(count):
                ray=V(1,0).rotate(i*360/count+rotation*(45 if rage else 20))
                side=ray.rotate(90)
                plate=[pos+ray*24-side*9,pos+ray*44-side*15,pos+ray*55+side*2,pos+ray*30+side*12]
                pg.draw.polygon(surface,fill,plate);pg.draw.lines(surface,edge,True,plate,1)
                pg.draw.line(surface,tint,pos+ray*34-side*6,pos+ray*45,3)
            core(pos,18,tint)
            if final:
                poly([(-25,-29),(-25,-48),(0,-34),(25,-48),(25,-29),(0,-23)],fill,tint)
                pg.draw.line(surface,tint,pos+V(-12,-32),pos+V(12,-32),3)
        if kind=='boss':
            self.text(variant.upper(),(pos.x,pos.y-r-36),10,PINK if rage else color,True,True,surface)

    def draw_gimmicks(self, surface):
        for item in self.world.gimmicks:
            kind=item['kind']
            if kind=='rail':
                rect=item['rect']
                pg.draw.rect(surface,(13,40,43),rect,border_radius=8)
                pg.draw.rect(surface,(48,110,101),rect,1,border_radius=8)
                offset=0 if self.reduced else int(self.visual_time*55)%55
                for y in range(rect.top+30+offset,rect.bottom-20,55):
                    pg.draw.lines(surface,MINT,False,[(rect.centerx-15,y+8),(rect.centerx,y),(rect.centerx+15,y+8)],2)
                self.text('BOOST',(rect.centerx,rect.top+17),11,MINT,True,True,surface)
            elif kind=='wall':
                rect=item['rect']
                pg.draw.rect(surface,(22,47,65),rect,border_radius=5)
                pg.draw.rect(surface,BLUE,rect,2,border_radius=5)
                for y in range(rect.top+12,rect.bottom-8,16):
                    pg.draw.line(surface,(70,110,140),(rect.left+5,y),(rect.right-5,y-5),2)
                self.text('COVER',(rect.centerx,rect.top-15),10,BLUE,True,True,surface)
            elif kind=='gravity':
                pos,r=item['pos'],item['r']
                for radius in (r,r-45,r-90):
                    pg.draw.circle(surface,(55,41,92),pos,radius,1)
                rotation=0 if self.reduced else self.visual_time*20
                for i in range(8):
                    ray=V(1,0).rotate(i*45+rotation)
                    side=ray.rotate(90)
                    point=pos+ray*105
                    pg.draw.lines(surface,(139,115,198),False,[point+ray*12-side*6,point,point+ray*12+side*6],2)
                self.glow(surface,pos,(151,119,240),30)
                pg.draw.circle(surface,(166,126,245),pos,14,2)
                self.text('GRAVITY',(pos.x,pos.y-r-16),11,(190,160,255),True,True,surface)
            else:
                pos,r,state=item['pos'],item['r'],item['state']
                if state=='idle':
                    pg.draw.circle(surface,(61,36,52),pos,r,1)
                    self.text('PULSE ZONE',(pos.x,pos.y),10,(94,66,83),True,True,surface)
                    continue
                color=GOLD if state=='warning' else PINK
                self.overlay.fill((0,0,0,0))
                pg.draw.circle(self.overlay,(*color,25 if state=='warning' else 60),pos,r)
                surface.blit(self.overlay,(0,0))
                pg.draw.circle(surface,color,pos,r,3)
                for i in range(8):
                    ray=V(1,0).rotate(i*45)
                    pg.draw.line(surface,color,pos+ray*(r-12),pos+ray*(r+8),2)
                if state=='warning':
                    pg.draw.circle(surface,color,pos,max(3,int(r*(1-max(0,min(1,item['progress']))))),2)
                else:
                    pg.draw.circle(surface,WHITE,pos,r-8,2)
                self.text('ESCAPE!' if state=='warning' else 'OVERLOAD',(pos.x,pos.y),13,color,True,True,surface)

    def draw_world(self):
        s = self.world_surface
        g = self.world
        s.blit(self.stage_backgrounds[g.phase], (0, 0))
        accent = STAGES[g.phase-1][2]
        pg.draw.rect(s, tuple(c // 2 for c in accent), ARENA, 2, border_radius=18)
        if g.phase==4:
            for radius in range(80,650,80):
                pg.draw.circle(s,(15,39,60),ARENA.center,radius,1)
            for i in range(12):
                ray=V(1,0).rotate(i*30+(self.visual_time*5 if not self.reduced else 0))
                pg.draw.line(s,(16,40,62),V(ARENA.center)+ray*65,V(ARENA.center)+ray*650,1)
        elif g.phase==5:
            for y in range(160,690,80):
                pg.draw.line(s,(53,23,38),(ARENA.left+4,y),(ARENA.right-4,y),2)
            for x in range(90,1200,100):
                pg.draw.lines(s,(69,28,42),False,[(x,ARENA.top+4),(x+16,ARENA.top+26),(x+32,ARENA.top+4)],2)
        if g.phase >= 2:
            shift = int(self.visual_time * 35) % 96
            for x in range(70 + shift, 1200, 96):
                pg.draw.line(s, tuple(c // 11 for c in accent), (x, 143), (x, 705), 1)
        self.draw_gimmicks(s)
        for h in g.hazards:
            active = h['age'] >= h['warn']
            color = PINK if active else GOLD
            coord = h['coord']
            a, b = laser_ends(h['axis'],coord)
            self.overlay.fill((0, 0, 0, 0))
            if active and not self.reduced:
                for width, alpha in ((150, 10), (110, 18), (85, 28)):
                    pg.draw.line(self.overlay, (*color, alpha), a, b, width)
            pg.draw.line(self.overlay, (*color, 38 if active else 15), a, b, 70 if active else 56)
            s.blit(self.overlay, (0, 0))
            if active:
                # Decorative energy trembles; the center and collision lane stay fixed.
                if not self.reduced:
                    direction = unit(b-a)
                    side = V(-direction.y, direction.x)
                    length = (b-a).length()
                    for sign in (-1, 1):
                        points = [a + direction*(length*i/20) + side*(sign*23 + math.sin(i*2.1+self.visual_time*65)*4) for i in range(21)]
                        pg.draw.lines(s, PINK, False, points, 2)
                    # Continuous, bounded light pulses and emitter sparks throughout firing.
                    pulse = (1+math.sin(self.visual_time*18))*.5
                    for end in (a, b):
                        pg.draw.circle(s, PINK, end, int(18+pulse*9), 3)
                        pg.draw.circle(s, (255, 219, 229), end, 10, 2)
                        for i in range(8):
                            angle = i*math.tau/8+self.visual_time*2
                            ray = V(math.cos(angle), math.sin(angle))
                            reach = 22+((self.visual_time*75+i*11)%26)
                            pg.draw.line(s, PINK, end+ray*16, end+ray*reach, 2)
                    for i in range(5):
                        point = a + direction*((self.visual_time*320+i*length/5)%length)
                        pg.draw.line(s, (255, 190, 215), point-side*25, point+side*25, 2)
                pg.draw.line(s, (127, 47, 76), a, b, 36)
                pg.draw.line(s, PINK, a, b, 30)
                core_width = 6 if self.reduced else 6+int((1+math.sin(self.visual_time*18))*2)
                pg.draw.line(s, (255, 219, 229), a, b, core_width)
            else:
                d = unit(b-a)
                progress = min(1, h['age']/h['warn'])
                pulse = 0 if self.reduced else (1+math.sin(self.visual_time*(12+progress*20)))*.5
                for distance in range(0, int((b-a).length()), 24):
                    pg.draw.line(s, color, a+d*distance, a+d*min(distance+13, (b-a).length()), 2)
                for end in (a, b):
                    pg.draw.circle(s, GOLD, end, 12, 2)
                    if not self.reduced:
                        pg.draw.circle(s, GOLD, end, int(21+pulse*7), 1)
                    pg.draw.arc(s, WHITE, pg.Rect(end.x-17,end.y-17,34,34), -math.pi/2,
                                -math.pi/2+max(.01,min(1,h['age']/h['warn']))*math.tau, 3)
            midpoint = a.lerp(b,.5)
            if not active:
                self.text('LASER / %.1f' % max(0,h['warn']-h['age']), (midpoint.x+17, midpoint.y-30), 12, GOLD, True, surface=s)
                if h.get('speed', 0):
                    move = laser_normal(h['axis'])
                    move *= 1 if h['speed'] > 0 else -1
                    for i in range(3):
                        tip = midpoint+move*(45+i*32)
                        side = V(-move.y,move.x)
                        pg.draw.lines(s,GOLD,False,[tip-move*12+side*8,tip,tip-move*12-side*8],3)
                    self.text('SWEEP', (midpoint.x+17,midpoint.y+22),12,GOLD,True,surface=s)
        for drop in g.drops:
            pos, kind = drop['pos'], drop['kind']
            color = MINT if kind=='repair' else BLUE if kind=='shield' else GOLD
            if not self.reduced:
                self.glow(s,pos,color,23)
            pg.draw.circle(s,color,pos,18,2)
            if kind=='repair':
                pg.draw.line(s,color,pos-V(8,0),pos+V(8,0),4)
                pg.draw.line(s,color,pos-V(0,8),pos+V(0,8),4)
            elif kind=='shield':
                pg.draw.polygon(s,color,[pos+V(-9,-9),pos+V(9,-9),pos+V(7,5),pos+V(0,12),pos+V(-7,5)],2)
            else:
                pg.draw.lines(s,color,False,[pos+V(5,-12),pos+V(-6,1),pos+V(5,1),pos+V(-5,12)],3)
            label = {'repair':'HP +1','shield':'SHIELD','nova':'NOVA'}[kind]
            self.text(label, (pos.x,pos.y-33),11,color,True,True,s)
            pg.draw.arc(s,color,pg.Rect(pos.x-23,pos.y-23,46,46),-math.pi/2,-math.pi/2+math.tau*max(.01,drop['life']/16),2)
        if g.shield:
            pg.draw.circle(s,BLUE,g.pos,29,2)
        for cell in g.cells:
            pos = cell['pos']
            self.glow(s, pos, BLUE, 20)
            pg.draw.polygon(s, BLUE, [pos+V(0,-14),pos+V(12,0),pos+V(0,14),pos+V(-12,0)], 3)
            self.text('LASER CELL', (pos.x, pos.y-30), 11, BLUE, True, True, s)
        if g.charge > 0:
            radius = int(55-30*g.charge/g.charge_duration)
            pg.draw.circle(s, BLUE, g.pos, radius, 3)
            pg.draw.line(s, (60, 110, 140), g.pos, g.pos+g.aim*1500, 1)
        if g.beam_left > 0:
            a, b = g.pos+g.beam_dir*24, g.pos+g.beam_dir*1600
            side = V(-g.beam_dir.y, g.beam_dir.x)
            if not self.reduced:
                self.overlay.fill((0,0,0,0))
                for width, alpha in ((170,12),(120,22),(85,45)):
                    pg.draw.line(self.overlay, (*BLUE,alpha), a,b,width)
                s.blit(self.overlay,(0,0))
                for i in range(1,20):
                    point = a+g.beam_dir*i*75
                    for sign in (-1,1):
                        crack = [point, point+side*sign*38+g.beam_dir*12,
                                 point+side*sign*(65+12*math.sin(i+self.visual_time*24))-g.beam_dir*16]
                        pg.draw.lines(s,GOLD,False,crack,2)
            pg.draw.line(s,BLUE,a,b,56)
            pg.draw.line(s,WHITE,a,b,18)
        for e in g.enemies:
            pos, r, kind = e['pos'], e['r'], e['kind']
            color = MINT if kind == 'drone' else PINK if kind == 'chaser' else GOLD if kind == 'shooter' else (184, 137, 255) if kind == 'bruiser' else (255, 154, 125)
            color = {'weaver':(100,220,255),'sniper':(255,135,80),'spinner':(222,120,255)}.get(kind,color)
            if e.get('supply'):
                color=BLUE
            if e['spawn'] > 0:
                radius = r + 15 + int(e['spawn'] * 18)
                pg.draw.circle(s, color, pos, radius, 1)
                pg.draw.line(s, color, pos - V(12, 0), pos + V(12, 0), 2)
                pg.draw.line(s, color, pos - V(0, 12), pos + V(0, 12), 2)
                continue
            if e['warn']:
                pg.draw.line(s, tuple(c // 3 for c in color), pos, pos + e['aim'] * (290 if kind == 'bruiser' else 460), 2)
                pg.draw.circle(s, color, pos, r + 8, 2)
            if not self.reduced:
                self.glow(s, pos, color, r)
            self.enemy_body(s,e,color)
            if e.get('practice') and g.time < 8:
                pg.draw.circle(s, GOLD, pos, r+14, 2)
                self.text('첫 목표 · 좌클릭!', (pos.x,pos.y-r-30), 16, GOLD, True, True, s)
            if e.get('practice_target'):
                pg.draw.circle(s,BLUE if e.get('laser_target') else GOLD,pos,r+14,2)
                self.text('LASER ONLY' if e.get('laser_target') else 'TARGET',(pos.x,pos.y-r-32),12,BLUE if e.get('laser_target') else GOLD,True,True,s)
            if kind == 'boss':
                radius = r + 13
                for i in range(4):
                    a = self.visual_time * (-1.8 if e['rage'] else .65) + i*math.pi/2
                    pg.draw.arc(s, PINK if e['rage'] else GOLD, pg.Rect(pos.x-radius,pos.y-radius,radius*2,radius*2), a, a+.9, 4)
                if e['rage']:
                    pg.draw.circle(s, PINK, pos, r+22, 1)
                    self.text('II',(pos.x,pos.y+r+34),16,PINK,True,True,s)
                    for i in range(6):
                        ray=V(1,0).rotate(i*60-self.visual_time*30)
                        pg.draw.line(s,PINK,pos+ray*(r+14),pos+ray*(r+25),3)
                if e.get('transform_left',0)>0 and not self.reduced:
                    pg.draw.circle(s,WHITE,pos,int(r+90*(1-e['transform_left']/.9)),2)
            elif kind == 'drone':
                pg.draw.circle(s, color, pos, r+8, 1)
                if e.get('supply'):
                    pg.draw.line(s,WHITE,pos-V(8,0),pos+V(8,0),3)
                    pg.draw.line(s,WHITE,pos-V(0,8),pos+V(0,8),3)
                self.text('CORE SUPPLY' if e.get('supply') else 'BONUS', (pos.x,pos.y-r-19), 10, color, True, True, s)
            if e['hp'] < e['maxhp']:
                pg.draw.rect(s, (47, 49, 68), (pos.x - r, pos.y - r - 13, 2 * r, 3))
                pg.draw.rect(s, color, (pos.x - r, pos.y - r - 13, max(0, 2 * r * e['hp'] / e['maxhp']), 3))
        for b in g.bullets:
            color = MINT if b['reflected'] else BLUE if b['friendly'] else GOLD
            if b['friendly'] and not b['reflected'] and 'weapon' in b:
                color = CHARACTERS[b['weapon']][2]
            if not self.reduced:
                self.glow(s, b['pos'], color, 8)
            if b['friendly']:
                pg.draw.line(s, color, b['pos'] - unit(b['vel']) * (18 if b['reflected'] else 10), b['pos'], 5 if b['reflected'] else 3)
                if b.get('weapon') == 2:
                    pg.draw.line(s,color,b['pos']-unit(b['vel'])*28,b['pos'],9)
                    pg.draw.circle(s,WHITE,b['pos'],3)
            else:
                pg.draw.circle(s, color, b['pos'], b['r'])
                pg.draw.circle(s, WHITE, b['pos'], 2)
                if b.get('bone'):
                    side=unit(b['vel']).rotate(90)*6
                    pg.draw.line(s,WHITE,b['pos']-side,b['pos']+side,4)
                    for sign in (-1,1):
                        pg.draw.circle(s,WHITE,b['pos']+side*sign,3)
        for t in self.trails:
            self.ship(s, t['pos'], t['aim'], tuple(int(c * max(.1, t['life'] / .25)) for c in CHARACTERS[self.character][2]), 17)
            if not self.reduced:
                side = V(-t['aim'].y, t['aim'].x)
                for sign in (-1, 1):
                    tip = t['pos'] + side*sign*22
                    pg.draw.line(s, BLUE, tip-t['aim']*38, tip, 2)
        if g.parry_time > 0:
            pg.draw.circle(s, MINT, g.pos, 94, 2)
            pg.draw.circle(s, (64, 142, 133), g.pos, 83, 1)
        if g.overdrive > 0:
            for i in range(3):
                angle = self.visual_time*4+i*math.tau/3
                point = g.pos + V(math.cos(angle),math.sin(angle))*33
                pg.draw.circle(s, GOLD, point, 4)
            pg.draw.circle(s, (63,122,99), g.pos, 38, 1)
        if g.opening and g.time < 5:
            pg.draw.arc(s, BLUE, pg.Rect(g.pos.x-31,g.pos.y-31,62,62), -math.pi/2,
                        -math.pi/2+max(.01,(5-g.time)/5)*math.tau, 3)
        if (g.opening and g.time < 5) or g.invulnerable <= 0 or int(self.visual_time * 16) % 2:
            if not self.reduced:
                self.glow(s, g.pos, CHARACTERS[self.character][2], 25)
            self.ship(s, g.pos, g.aim, BLUE if g.dash_time > 0 else CHARACTERS[self.character][2])
        for p in self.particles:
            color = tuple(int(c * min(1, p['life'] * 3)) for c in p['color'])
            if not self.reduced:
                pg.draw.line(s, color, p['pos']-p['vel']*.032, p['pos'], 2)
            pg.draw.circle(s, color, p['pos'], p['size'])
        for r in self.rings:
            fraction = 1 - r['life'] / r['max']
            pg.draw.circle(s, tuple(int(c * (1 - fraction)) for c in r['color']), r['pos'], max(1, int(r['radius'] * fraction)), 2)
            if r.get('spokes') and not self.reduced:
                color = tuple(int(c * (1-fraction)) for c in r['color'])
                for i in range(12):
                    angle = i*math.tau/12
                    ray = V(math.cos(angle), math.sin(angle))
                    near = r['pos'] + ray*r['radius']*fraction*.8
                    far = r['pos'] + ray*r['radius']*min(1, fraction+.14)
                    pg.draw.line(s, color, near, far, 2)
        for label in self.labels:
            self.text(label['text'], label['pos'], 18, GOLD, True, True, s)
        if self.desaturation > .01:
            gray = pg.transform.grayscale(s)
            gray.set_alpha(int(255*self.desaturation))
            s.blit(gray,(0,0))
        self.canvas.fill((8, 13, 25))
        offset = self.camera_offset()
        self.canvas.blit(s, offset)
        if self.zoom > 0 and not self.reduced:
            factor = 1 + self.zoom*.045
            size = (int(W*factor),int(H*factor))
            self.canvas.blit(pg.transform.smoothscale(s,size), ((W-size[0])/2+offset[0],(H-size[1])/2+offset[1]))
        if self.flash > 0 and not self.reduced:
            self.overlay.fill((255,190,137,int(self.flash*125)))
            self.canvas.blit(self.overlay,(0,0))
        if self.damage_tint > 0:
            amount = self.damage_tint/.6
            self.overlay.fill((220, 12, 25, int((40 if self.reduced else 85)*amount)))
            self.canvas.blit(self.overlay,(0,0))
            pg.draw.rect(self.canvas, (int(210*amount), 18, 28), ARENA, max(1,int(7*amount)), border_radius=18)

    def panel(self, rect):
        self.overlay.fill((3,9,15,215))
        self.canvas.blit(self.overlay,(0,0))
        r=pg.Rect(rect)
        self.frame(r,(12,23,33),(63,87,100),MINT)
        pg.draw.line(self.canvas,(32,49,61),(r.x+32,r.y+110),(r.right-32,r.y+110))
        self.mark((r.right-65,r.y+27),MINT,.8)

    def draw_hud(self):
        g=self.world
        accent=STAGES[g.phase-1][2]
        self.frame((54,18,1172,101),(9,18,27),(45,66,77))
        self.mark((74,37),MINT,.95)
        self.text('PULSE BREAKER',(114,34),15,WHITE,True,display=True)
        self.text('ROUND %02d  /  SECTOR %02d' % (g.round,g.phase),(74,63),11,accent,True)
        for i in range(5):
            pg.draw.rect(self.canvas,accent if i<g.phase else (40,55,67),(74+i*42,86,34,3))
        for x in (300,590,822,1035):
            pg.draw.line(self.canvas,(37,54,66),(x,35),(x,95))
        self.text('SCORE',(324,29),10,MUTED,True)
        score=f'{g.score:,}' if g.score<10000000 else f'{g.score/1000000:.2f}M'
        self.text(score,(324,49),28,MINT,True,display=True)
        self.text('%02d CHAIN  /  ×%d' % (g.streak,min(4,1+g.streak//5)),(325,85),11,MUTED)
        health=PINK if g.hp<=2 and not g.practice else MINT
        self.text(CHARACTERS[self.character][0]+' / 체력',(612,29),10,CHARACTERS[self.character][2],True)
        self.text('%02d' % g.hp,(612,50),25,health,True,display=True)
        self.text('/ %02d' % g.max_hp,(660,57),13,MUTED)
        for i in range(g.max_hp):
            x=613+i*25
            pg.draw.polygon(self.canvas,health if i<g.hp else (37,52,64),[(x,90),(x+5,80),(x+22,80),(x+17,90)])
        if g.shield:self.text('+ SHIELD',(714,54),11,BLUE,True)
        self.text('BREAKER CORE',(844,29),10,MUTED,True)
        for i in range(2):
            x=853+i*24;y=59
            pg.draw.polygon(self.canvas,BLUE if i<g.laser_ammo else (46,62,73),[(x,y-9),(x+8,y),(x,y+9),(x-8,y)],0 if i<g.laser_ammo else 1)
        status='CHARGE %d%%' % (g.charge/g.charge_duration*100) if g.charge>0 else 'FIRING' if g.beam_left>0 else 'HOLD CLICK' if g.laser_ammo else 'FIND A CORE'
        self.text(status,(897,53),11,BLUE if g.laser_ammo or g.beam_left else MUTED,True)
        self.meter((845,85,166,4),g.charge/g.charge_duration if g.charge else g.beam_left/1.4 if g.beam_left else g.laser_ammo/2,BLUE)
        seconds=math.ceil(max(0,45-g.time)) if g.practice else math.ceil(max(0,60-g.time)) if self.festival else int(g.time)
        minutes,seconds=divmod(seconds,60)
        elapsed=f'{minutes:02d}:{seconds:02d}' if minutes<60 else f'{minutes//60}:{minutes%60:02d}:{seconds:02d}'
        self.text('TRAINING' if g.practice else 'TIME LEFT' if self.festival else 'SURVIVAL',(1059,29),10,MUTED,True)
        self.text(elapsed,(1058,51),25,WHITE,True,display=True)
        self.text('45s / SAFE' if g.practice else '60s / FESTIVAL' if self.festival else 'ENDLESS RUN',(1059,85),10,accent)
        # Skill dock sits outside the arena and stays steady during camera shakes.
        for label,key,x,value,ready in [('대시','SHIFT',54,1-g.dash_cd/g.dash_cooldown,g.dash_cd<=0),
                                       ('탄환 반사','RMB / E',271,1-g.parry_cd/g.parry_cooldown,g.parry_cd<=0)]:
            self.frame((x,732,204,56),(12,23,33),(41,62,76))
            self.keycap(key,(x+12,742),62)
            self.text(label,(x+86,742),13,WHITE,True)
            self.text('READY' if ready else '%.1fs' % (g.dash_cd if x==54 else g.parry_cd),(x+86,761),10,MINT if ready else MUTED)
            self.meter((x+12,779,179,3),value,MINT if ready else BLUE)
        self.frame((488,732,738,56),(12,23,33),(41,62,76))
        if g.opening and g.time<18:
            completed=[g.kills>0,g.distance_moved>=60,g.dashes_used>0]
            instruction=('첫 목표를 겨냥하고 좌클릭하세요.' if not completed[0] else
                         '방향키로 이동해 보세요.' if not completed[1] else
                         '방향키 + Shift로 무적 대시!' if not completed[2] else '드론을 잡아 무기를 강화하세요!')
            self.text(instruction,(508,741),15,MINT,True)
            self.text('처음 5초는 보호됩니다' if g.time<5 else '우클릭 / E로 적의 탄환을 반사하세요.',(508,765),11,MUTED)
        else:
            self.text('방향키 이동 · 좌클릭 사격 / 코어 보유 시 충전',(508,741),14,WHITE)
            self.text('안전 연습 · 기록 없음' if g.practice else GIMMICK_NAMES[g.phase-1],(508,765),11,BLUE)
        self.text('ESC  PAUSE',(1108,743),10,MUTED,True)
        self.text('NEAR MISS %02d' % g.near_misses,(1100,766),10,BLUE if g.charge_bonus else MUTED)
        if g.charge_bonus:
            self.text('CHARGE +%d%%' % (g.charge_bonus*100),(1100,705),10,BLUE,True)
        if g.overdrive>0:
            self.frame((1008,139,205,34),(34,29,23),(100,78,48),GOLD)
            self.text('OVERDRIVE  %.1fs' % g.overdrive,(1022,147),12,GOLD,True)
            self.meter((1020,167,180,2),g.overdrive/6,GOLD)
        bosses=[e for e in g.enemies if e['kind']=='boss' and e['spawn']<=0]
        if bosses and not g.practice:
            e=bosses[0]
            self.frame((422,135,436,42),(27,18,26),(98,48,61),PINK)
            self.text(BOSS_NAMES.get(e.get('variant'),'CORE')+('  /  PHASE II' if e['rage'] else '  /  PHASE I'),(640,148),11,PINK,True,True)
            self.meter((440,166,400,4),e['hp']/e['maxhp'],PINK)
        if g.practice and self.state=='play' and g.practice_step<4:
            self.frame((250,154,780,98),(11,23,34),(54,84,101),BLUE)
            title,detail=PRACTICE_LESSONS[g.practice_step]
            if g.practice_step==0:
                if g.kills>0 and not g.shots_fired:detail='좌클릭으로 기본 사격도 한 번 사용해 보세요.'
                elif g.kills>0:detail='첫 목표 격파! 이제 방향키로 움직여 보세요.'
                elif g.distance_moved>=80:detail='이동 성공! 분홍색 목표를 겨냥하고 좌클릭하세요.'
            self.text('%02d / 04  %s' % (g.practice_step+1,title),(640,178),19,MINT,True,True)
            self.text(detail,(640,209),15,WHITE,center=True)
            for i,done in enumerate(g.practice_marks):
                pg.draw.rect(self.canvas,MINT if done else BLUE if i==g.practice_step else (43,59,72),(572+i*36,236,25,3))
        if self.toast_left>0 and self.state=='play' and not g.practice and not self.stage_banner:
            self.text(self.toast[0],(640,205),30,GOLD if self.toast[0]=='REFLECT!' else MINT,True,True)
            self.text(self.toast[1],(640,239),13,WHITE,center=True)
        if self.stage_banner>0 and self.state=='play':
            self.frame((300,190,680,82),(9,19,30),(47,78,91),accent)
            title,detail,color=STAGES[g.phase-1]
            self.text('R%02d  /  %s' % (g.round,title),(640,215),27,color,True,True)
            self.text(detail,(640,248),14,WHITE,center=True)

    def draw_menu(self):
        self.canvas.blit(self.menu_background,(0,0))
        self.mark((84,54),MINT,1.2)
        self.text('PULSE BREAKER',(139,49),19,WHITE,True,display=True)
        self.text('NEON ARENA / PRECISION ACTION',(84,91),10,MUTED,True)
        self.button('sound','소리 '+('ON' if self.audio.enabled else 'OFF'),(745,51,108,37))
        self.button('motion_intense','강렬한 연출',(867,51,158,37),not self.reduced)
        self.button('motion_calm','차분한 연출',(1039,51,158,37),self.reduced)
        self.text('진동·섬광 OFF / 입자 축소' if self.reduced else '진동·섬광 ON / 빛 번짐',(746,101),11,MUTED)
        self.text('FESTIVAL  /  60 SECOND RUN' if self.festival else 'SURVIVAL  /  ENDLESS RUN',(84,157),12,MINT,True)
        self.text('PULSE',(80,193),76,WHITE,True,display=True,tracking=1.5)
        self.text('BREAKER',(80,278),69,MINT,True,display=True,tracking=1)
        self.text('한 발의 쾌감. 한계를 넘는 컨트롤.',(85,375),22,WHITE,True)
        self.text('4종의 전투기, 5개의 전장. 당신의 기록에 도전!',(86,418),15,MUTED)
        self.text('60초의 짧고 강렬한 도전' if self.festival else '최종 보스 이후에도 계속되는 무한 생존',(86,449),15,MINT)
        self.text('PLAYER NAME',(86,481),10,MUTED,True)
        self.frame((84,502,378,47),(11,23,34),PINK if self.name_error else MINT if self.name_active else (65,85,100))
        preview_name=self.name+self.composition
        shown=('•'*len(preview_name) if name_problem(preview_name) else preview_name) or '별명 / 참가 번호 (선택)'
        self.text(shown,(99,515),16,WHITE if self.name else MUTED)
        if self.name_active and (self.reduced or int(self.visual_time*2)%2==0):
            end=self.font(32).size(shown)[0]/2
            pg.draw.line(self.canvas,MINT,(min(445,102+end),516),(min(445,102+end),536))
        self.text('다른 별명이나 참가 번호를 써 주세요.' if self.name_error else '욕설·모욕·비하 표현은 사용할 수 없어요.',(87,550),11,PINK if self.name_error else MUTED)
        self.button('start','출격하기  /  ENTER',(84,577,378,54),True)
        self.button('guide','조작 가이드 / H',(84,643,180,42))
        self.button('practice','안전 연습 / T',(278,643,184,42))
        self.button('exit','게임 종료',(84,697,378,26))
        accent=CHARACTERS[self.character][2]
        self.frame((632,149,574,274),(11,24,35),(61,82,97),accent)
        self.text('SELECT YOUR FIGHTER  /  %02d' % (self.character+1),(654,166),10,MUTED,True)
        latin=['PULSE','RAVEN','TITAN','NOVA'][self.character]
        self.text(latin,(653,198),30,accent,True,display=True,tracking=.5)
        self.text(CHARACTERS[self.character][0]+' / '+WEAPONS[self.character],(655,239),14,WHITE,True)
        self.text('HULL',(655,276),10,MUTED,True)
        for i in range((5,4,7,4)[self.character]):
            pg.draw.rect(self.canvas,accent,(698+i*12,278,8,6))
        self.text('SPEED',(655,303),10,MUTED,True)
        for i in range(7):
            pg.draw.rect(self.canvas,accent if i<(5,7,3,5)[self.character] else (40,58,72),(698+i*12,305,8,6))
        self.text('STYLE / '+['INTERCEPTOR','STEALTH','HEAVY ARMOR','ENERGY'][self.character],(655,350),10,MUTED,True)
        self.text(CHARACTERS[self.character][1],(655,378),12,accent)
        for radius in (92,110):
            pg.draw.circle(self.canvas,(34,55,68),(1030,286),radius,1)
        rotation=0 if self.reduced else self.visual_time*.12
        for i in range(4):
            pg.draw.arc(self.canvas,accent,(920,176,220,220),rotation+i*math.pi/2,rotation+i*math.pi/2+.24,2)
        self.glow(self.canvas,V(1030,286),accent,75)
        bob=0 if self.reduced else math.sin(self.visual_time*(2.2,1.1,.65,1.6)[self.character])*(6,3,1,5)[self.character]
        self.canvas.blit(self.hero(self.character),(855,141+bob))
        for i,(name,_,color,_) in enumerate(CHARACTERS):
            r=pg.Rect(632+i*146,437,136,62)
            self.buttons['character_'+str(i)]=r
            self.frame(r,(24,39,50) if i==self.character else (12,24,34),color if i==self.character else (53,74,87),color if i==self.character else None)
            self.ship(self.canvas,V(r.x+30,r.y+30),unit((1,-.3)),color,15,character=i)
            self.text(name,(r.x+58,r.y+12),14,color if i==self.character else WHITE,True)
            self.text('SELECTED' if i==self.character else 'SELECT',(r.x+58,r.y+36),9,color if i==self.character else MUTED,True)
        self.frame((632,507,574,30),(12,24,38),(54,68,102))
        self.text(['충격 반사','관통 대시','중장갑 보호막','에너지 폭발'][self.character]+'  /  '+ABILITIES[self.character],(644,515),12,accent)
        self.frame((632,548,574,175),(10,22,32),(48,68,82))
        self.text('LOCAL LEADERBOARD',(654,561),11,WHITE,True)
        self.text('60s / FESTIVAL' if self.festival else 'ENDLESS SURVIVAL',(1064,562),9,MINT)
        pg.draw.line(self.canvas,(40,57,69),(654,585),(1185,585))
        for i,record in enumerate(self.records[:4]):
            y=594+i*29
            self.text('%02d' % (i+1),(655,y),13,GOLD if i==0 else MUTED,True)
            self.text(record['name'][:12],(697,y),13,WHITE if i==0 else MUTED)
            value=self.font(14,True,True).render(f'{record["score"]:,}',True,WHITE)
            self.canvas.blit(value,(1182-value.get_width(),y))
        if not self.records:
            self.text('아직 기록이 없습니다. 첫 번째 파일럿이 되어 보세요.',(654,626),14,MUTED)
            self.text('이 기기에 점수가 저장됩니다.',(654,660),11,MUTED)
        self.text('↑ ↓ ← → 이동     SHIFT 대시     우클릭 / E 반사',(84,748),13,MUTED)
        self.text('F11 전체 화면',(84,773),10,MUTED)
        self.text('OFFLINE ARCADE  /  '+('FESTIVAL' if self.festival else 'SURVIVAL'),(975,751),11,MUTED,True)
        if not self.storage_ok:self.text('저장 제한: 실행 중에만 기록 유지',(946,775),11,GOLD)

    def draw(self):
        self.buttons = {}
        if self.state == 'menu':
            self.draw_menu()
        else:
            self.draw_world()
            self.draw_hud()
            if self.state == 'countdown':
                self.frame((538,256,204,187),(10,25,35),(62,112,120),MINT)
                self.text('SYSTEM READY',(640,280),11,MUTED,True,True)
                self.text(str(max(1,math.ceil(self.count))),(640,360),105,MINT,True,True)
                self.text('방향키 이동 · 마우스 조준 · 좌클릭 사격',(640,474),18,WHITE,center=True)
            elif self.state == 'pause':
                self.panel((384,160,512,526))
                self.text('FLIGHT PAUSED',(424,190),11,MINT,True)
                self.text('잠깐, 숨 고르기.',(424,220),30,WHITE,True)
                self.text('시간과 전투가 멈췄습니다.',(424,277),16,MUTED)
                self.button('resume','계속하기  /  ENTER',(424,328,432,52),True)
                self.button('menu','도전 종료 · 로비로',(424,394,432,43))
                self.text('중간 종료 기록은 저장하지 않습니다.',(424,455),12,MUTED)
                self.text('EFFECT INTENSITY',(424,512),11,WHITE,True)
                self.button('motion_intense','강렬한 연출',(424,544,210,40),not self.reduced)
                self.button('motion_calm','차분한 연출',(646,544,210,40),self.reduced)
                self.text('난이도와 점수는 동일합니다.',(424,613),12,MUTED)
                self.text('ESC / ENTER  RESUME',(424,650),10,MUTED,True)
            elif self.state == 'guide':
                self.panel((262,80,756,645))
                self.text('PILOT HANDBOOK',(302,111),11,MINT,True)
                self.text('컨트롤이 곧 생존입니다.',(302,140),30,WHITE,True)
                lines=[('↑ ↓ ← →','이동','대각선에서도 같은 속도로 이동합니다.'),
                       ('LMB / SPACE','사격 / 충전','코어 획득 후 버튼을 유지하면 레이저가 발사됩니다.'),
                       ('SHIFT','무적 대시','이동 방향으로 돌파합니다. 정지 중에는 조준 방향으로 이동합니다.'),
                       ('RMB / E / CTRL','탄환 반사','0.22초 동안 적 탄환을 반사해 3배 피해를 줍니다.'),
                       ('ESC / F11','화면 조작','일시정지 / 전체 화면 전환')]
                for i,(key,title,detail) in enumerate(lines):
                    y=213+i*72
                    self.frame((302,y,126,49),(22,36,47),(59,82,96))
                    self.text(key,(365,y+24),13,MINT,True,True)
                    self.text(title,(448,y),16,WHITE,True)
                    self.text(detail,(448,y+29),13,MUTED)
                self.text('선·원 표시는 공격 예고입니다. 드론을 잡으면 충전 레이저 코어를 얻습니다.',(302,588),13,GOLD)
                self.text('15기 격파마다 체력 회복 · 5기마다 회복 / 보호막 / 충격파 드롭',(302,615),12,MUTED)
                self.button('back','준비 완료 · 로비로',(302,655,676,43),True)
            elif self.state == 'practice_result':
                self.panel((332,123,616,558))
                self.text('TRAINING DEBRIEF',(374,155),11,MINT,True)
                self.text('실전으로 출발!',(374,185),32,WHITE,True)
                for i,(title,_) in enumerate(PRACTICE_LESSONS):
                    y=266+i*43;passed=self.world.practice_marks[i]
                    self.frame((374,y,36,29),(20,36,45),(52,74,86))
                    self.text('OK' if passed else '--',(392,y+14),11,MINT if passed else MUTED,True,True)
                    self.text(title,(427,y+4),17,WHITE if passed else MUTED,True)
                self.text('연습 점수는 순위표에 저장되지 않습니다.',(374,464),14,MUTED)
                self.button('start','실전 시작  /  ENTER',(374,517,532,50),True)
                self.button('practice_again','다시 연습',(374,581,259,42))
                self.button('menu','로비로',(647,581,259,42))
                self.text('TRAINING / SAFE FLIGHT',(374,650),10,MUTED,True)
            elif self.state == 'result':
                self.panel((322,94,636,627))
                g=self.world
                title='CORE CLEAR' if self.festival and g.finish_reason=='clear' else 'TIME UP' if self.festival and g.finish_reason=='time' else 'FESTIVAL RECORD' if self.festival else 'SURVIVAL RECORD'
                self.text(title,(364,125),11,MINT,True)
                self.text('다시, 한계를 넘어서.',(364,154),30,WHITE,True)
                self.text('TOTAL SCORE',(364,231),11,MUTED,True)
                score_size=58
                while score_size>20 and self.font(score_size,True,True,True).size(f'{g.score:,}')[0]>550:
                    score_size-=2
                self.text(f'{g.score:,}',(360,254),score_size,MINT,True)
                self.text('%s · R%02d · %.1f초' % (CHARACTERS[self.character][0],g.round,g.time),(364,337),15,MUTED)
                stats=[('ELIMINATIONS',g.kills),('REFLECTIONS',g.reflected),('BEST CHAIN',g.best_streak)]
                for i,(label,value) in enumerate(stats):
                    x=364+i*185
                    self.frame((x,385,172,83),(17,31,42),(46,67,81))
                    self.text(label,(x+13,396),10,MUTED,True)
                    self.text(str(value),(x+12,419),29,WHITE,True)
                self.text('LOCAL RANK  #%02d   /   NEAR MISS %d' % (self.rank,g.near_misses),(364,490),12,GOLD,True)
                self.text('기록 저장 완료' if self.storage_ok else '현재 실행 중에만 기록 유지',(364,517),12,MUTED)
                self.button('again','다시 도전  /  ENTER',(364,557,552,50),True)
                self.button('next','다음 참가자 · 로비로',(364,621,552,42))
                self.text('DEBRIEF COMPLETE',(364,690),10,MUTED,True)
        if self.state == 'play':
            pg.draw.circle(self.canvas, WHITE, self.mouse, 9, 1)
            for d in [V(1, 0), V(-1, 0), V(0, 1), V(0, -1)]:
                pg.draw.line(self.canvas, WHITE, self.mouse + d * 13, self.mouse + d * 18, 1)
        width, height = self.screen.get_size()
        self.scale = min(width / W, height / H)
        size = (max(1, int(W * self.scale)), max(1, int(H * self.scale)))
        self.offset = V((width - size[0]) / 2, (height - size[1]) / 2)
        self.screen.fill((3, 6, 12))
        self.screen.blit(pg.transform.smoothscale(self.canvas, size) if size != (W, H) else self.canvas, self.offset)
        pg.mouse.set_visible(self.state != 'play')
        pg.display.flip()

    def run(self):
        clock = pg.time.Clock()
        while self.running:
            dt = clock.tick(120) / 1000
            for event in pg.event.get():
                self.handle(event)
            self.update(dt)
            self.draw()
        pg.quit()


def main():
    parser = argparse.ArgumentParser(description='PULSE BREAKER · 방향키 액션 게임')
    parser.add_argument('--data-dir', help='점수 및 설정 저장 폴더')
    parser.add_argument('--mode', choices=('normal','festival'), default='normal', help='일반 무한 / 행사 60초')
    args = parser.parse_args()
    App(args.data_dir, festival=args.mode == 'festival').run()


if __name__ == '__main__':
    main()
